<?php
// En-tête HTTP pour forcer l'encodage UTF-8 dans le navigateur
header('Content-Type: text/html; charset=utf-8');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION["admin"])) {
    exit("Accès refusé");
}

require_once "config.php";

if (isset($_POST["push"])) {
    require_once "send_push.php";
}

if (isset($_POST["sujet"])) {

    // --- Gestion des images optionnelles jointes au message (5 max) ---
    $imageUrls = [];
    $erreurImage = "";

    $imagesEnvoyees = $_FILES['images'] ?? null;
    $nombreFichiers = ($imagesEnvoyees && isset($imagesEnvoyees['name'])) ? count(array_filter($imagesEnvoyees['name'])) : 0;

    if ($nombreFichiers > 5) {
        $erreurImage = "5 images maximum autorisées par message.";
    } elseif ($nombreFichiers > 0) {

        $typesAutorises = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];
        $extensionsParType = [
            'image/png'  => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
            'image/gif'  => 'gif',
        ];
        $tailleMaxOctets = 5 * 1024 * 1024; // 5 Mo par image

        $dossierUpload = __DIR__ . "/uploads/broadcast";
        if (!is_dir($dossierUpload)) {
            mkdir($dossierUpload, 0755, true);
        }

        $protocole = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';

        for ($i = 0; $i < $nombreFichiers; $i++) {

            if (empty($imagesEnvoyees['name'][$i])) {
                continue;
            }

            if ($imagesEnvoyees['error'][$i] !== UPLOAD_ERR_OK) {
                $erreurImage = "Erreur lors de l'envoi d'une des images.";
                break;
            }
            if ($imagesEnvoyees['size'][$i] > $tailleMaxOctets) {
                $erreurImage = "Une image dépasse 5 Mo.";
                break;
            }

            $typeReel = mime_content_type($imagesEnvoyees['tmp_name'][$i]);
            if (!in_array($typeReel, $typesAutorises, true)) {
                $erreurImage = "Format d'image non autorisé (PNG, JPEG, WEBP ou GIF uniquement).";
                break;
            }

            $nomFichier = bin2hex(random_bytes(16)) . "." . $extensionsParType[$typeReel];
            $cheminComplet = $dossierUpload . "/" . $nomFichier;

            if (move_uploaded_file($imagesEnvoyees['tmp_name'][$i], $cheminComplet)) {
                $imageUrls[] = $protocole . $_SERVER['HTTP_HOST'] . "/uploads/broadcast/" . $nomFichier;
            } else {
                $erreurImage = "Impossible d'enregistrer une des images sur le serveur.";
                break;
            }
        }
    }

    // 1. Insertion initiale du message dans la BDD
    $stmt = $pdo->prepare("
        INSERT INTO messages_admin (
            sujet,
            message,
            images,
            envoyer_email,
            envoyer_push,
            afficher_dashboard,
            cible
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $_POST["sujet"],
        $_POST["message"],
        !empty($imageUrls) ? json_encode($imageUrls) : null,
        isset($_POST["email"]) ? 1 : 0,
        isset($_POST["push"]) ? 1 : 0,
        isset($_POST["dashboard"]) ? 1 : 0,
        $_POST["cible"]
    ]);

    $messageId = $pdo->lastInsertId();

    require_once "mail.php";

    // 2. Sélection des destinataires selon la cible
    $cible = $_POST["cible"];

    if ($cible == "tous") {
        $users = $pdo->query("
            SELECT email
            FROM users
        ")->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($cible == "paye") {
        $users = $pdo->query("
            SELECT DISTINCT identifiant AS email
            FROM demandes
            WHERE statut='paye'
        ")->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($cible == "attente") {
        $users = $pdo->query("
            SELECT DISTINCT identifiant AS email
            FROM demandes
            WHERE statut='en_attente'
        ")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $users = $pdo->query("
            SELECT DISTINCT identifiant AS email
            FROM demandes
            WHERE statut='expired'
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    $totalDestinataires = count($users);

    $avertissementAucunDestinataire = ($totalDestinataires === 0);

    // Mettre à jour le total des destinataires et passer le statut en cours
    $pdo->prepare("
        UPDATE messages_admin
        SET total_destinataires = ?,
            statut_envoi = 'en_cours'
        WHERE id = ?
    ")->execute([
        $totalDestinataires,
        $messageId
    ]);

    $emailsEnvoyes = 0;

    // 3. Traitement de l'envoi des e-mails
    if (isset($_POST["email"])) {

        $corpsMessage = nl2br($_POST["message"]);
        if (!empty($imageUrls)) {
            $corpsMessage .= '<br><br>';
            foreach ($imageUrls as $url) {
                $corpsMessage .= '<img src="' . htmlspecialchars($url) . '" alt="" style="max-width:100%;border-radius:8px;margin-bottom:10px;display:block;">';
            }
        }

        foreach ($users as $u) {

            $email = trim($u["email"]);

            // On vérifie que l'email n'est pas vide
            if (!empty($email)) {

                // Exécution de l'envoi et stockage du résultat (booléen)
                $result = sendMail(
                    $email,
                    $_POST["sujet"],
                    $corpsMessage
                );

                if ($result) {
                    $emailsEnvoyes++;

                    $pdo->prepare("
                        UPDATE messages_admin
                        SET emails_envoyes = ?
                        WHERE id = ?
                    ")->execute([
                        $emailsEnvoyes,
                        $messageId
                    ]);

                    echo "✔ Envoyé : " . htmlspecialchars($email) . "<br>";
                } else {
                    echo "❌ Erreur d'envoi : " . htmlspecialchars($email) . "<br>";
                }

                flush(); // Force l'affichage en direct
            }
        }
    }

    // 4. Traitement des notifications Push
    if (isset($_POST["push"])) {

        $pushEnvoyes = sendPush(
            $_POST["sujet"],
            $_POST["message"]
        );

        $pdo->prepare("
            UPDATE messages_admin
            SET push_envoyes = ?
            WHERE id = ?
        ")->execute([
            $pushEnvoyes,
            $messageId
        ]);
    }

    // 5. Clôture de l'envoi
    $pdo->prepare("
        UPDATE messages_admin
        SET statut_envoi = 'termine'
        WHERE id = ?
    ")->execute([
        $messageId
    ]);

    $success = true;
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Envoyer un message</title>
    <link rel="stylesheet" href="admin_style.css?v=<?= @filemtime(__DIR__.'/admin_style.css') ?: time() ?>">
</head>

<body class="admin-page">

    <?php $admin_nav_active = 'broadcast'; include "admin_nav.php"; ?>

    <div class="admin-card" style="max-width:700px;margin:0 auto;">

        <h2 class="admin-title">📬 Envoyer un message aux utilisateurs</h2>
        <p class="admin-subtitle">Diffusion par email, notification push et/ou tableau de bord.</p>

        <form method="post" enctype="multipart/form-data">
            <?php if (isset($success) && !empty($avertissementAucunDestinataire)): ?>
                <div class="admin-alert admin-alert-warning">
                    ⚠️ Message enregistré, mais <u>aucun destinataire</u> ne correspond à la cible choisie — aucun email/push n'a été envoyé.
                </div>
            <?php elseif (isset($success)): ?>
                <div class="admin-alert admin-alert-success">
                    ✅ Message enregistré avec succès.
                </div>
            <?php endif; ?>
            <?php if (!empty($erreurImage)): ?>
                <div class="admin-alert admin-alert-danger">
                    ❌ <?php echo htmlspecialchars($erreurImage); ?>
                </div>
            <?php endif; ?>

            <label class="admin-label">Sujet</label>
            <input class="admin-input" type="text" name="sujet" placeholder="Sujet" required>

            <label class="admin-label">Message</label>
            <textarea class="admin-textarea" name="message" rows="8" placeholder="Votre message..." required></textarea>

            <label class="admin-label">🖼️ Images (optionnelles, 5 max)</label>
            <input class="admin-input" type="file" name="images[]" accept="image/png,image/jpeg,image/webp,image/gif" multiple>

            <label class="admin-label" style="margin-top:24px;">Destinataires</label>
            <select class="admin-select" name="cible">
                <option value="tous">Tous</option>
                <option value="paye">Paiements confirmés</option>
                <option value="attente">Paiements en attente</option>
                <option value="expired">Paiements expirés</option>
            </select>

            <div style="margin-top:18px;display:flex;flex-direction:column;gap:10px;">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" name="email">
                    📧 Envoyer par Email
                </label>

                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" name="push">
                    🔔 Notification Push
                </label>

                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" name="dashboard">
                    💻 Afficher sur le tableau de bord
                </label>
            </div>

            <button class="admin-btn admin-btn-success" style="margin-top:24px;" type="submit">📨 Envoyer</button>
        </form>

    </div>

</body>

</html>
