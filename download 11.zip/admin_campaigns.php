<?php

session_start();

if(!isset($_SESSION["admin"])){
    exit("Accès refusé");
}

require_once "config.php";

$messages = $pdo->query("
SELECT *
FROM messages_admin
ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>

<html lang="fr">

<head>

<meta charset="UTF-8">

<title>Historique des campagnes</title>

<link rel="stylesheet" href="admin_style.css?v=<?= @filemtime(__DIR__.'/admin_style.css') ?: time() ?>">

</head>

<body class="admin-page">

<?php $admin_nav_active = 'campagnes'; include "admin_nav.php"; ?>

<h2 class="admin-title">📢 Historique des campagnes</h2>
<p class="admin-subtitle">Suivi de toutes les diffusions envoyées aux utilisateurs.</p>

<div class="admin-card">
<div class="admin-table-wrap">
<table class="admin-table">

<thead>
<tr>

<th>ID</th>

<th>Sujet</th>

<th>Cible</th>

<th>Date</th>

<th>Emails</th>

<th>Push</th>

<th>Dashboard</th>

<th>Progression</th>
<th>Actions</th>
</tr>
</thead>

<tbody>
<?php foreach($messages as $m): ?>

<tr>

<td><?= $m["id"] ?></td>

<td><?= htmlspecialchars($m["sujet"]) ?></td>

<td><?= htmlspecialchars($m["cible"]) ?></td>

<td><?= $m["date_creation"] ?></td>

<td>
<?= $m["envoyer_email"] ? "✅":"❌" ?>
</td>

<td>
<?= $m["envoyer_push"] ? "✅":"❌" ?>
</td>

<td><?= $m["afficher_dashboard"] ? "✅":"❌" ?></td>
<td>

<?php

$total = $m["total_destinataires"];

if($total > 0){

   $envoyes = max(
    $m["emails_envoyes"],
    $m["push_envoyes"]
);

$pourcentage = round(
    ($envoyes / $total) * 100
);

}else{

    $pourcentage = 0;

}

?>

<div style="width:160px;height:8px;background:var(--admin-border-strong);border-radius:20px;overflow:hidden;">

<div style="width:<?= $pourcentage ?>%;height:100%;background:var(--admin-success);">

</div>

</div>


<div style="margin-top:6px;font-size:12px;color:var(--admin-text-muted);">

<?= $m["emails_envoyes"] ?>
/
<?= $total ?>
envoyés
&nbsp;
<?php if($m["statut_envoi"]=="en_cours"): ?>
<span class="admin-badge admin-badge-warning">⏳ En cours</span>
<?php else: ?>
<span class="admin-badge admin-badge-success">✅ Terminé</span>
<?php endif; ?>

</div>


</td>
<td style="white-space:nowrap;">

<a
href="view_campaign.php?id=<?= $m["id"] ?>"
class="admin-btn admin-btn-ghost"
style="padding:6px 10px;font-size:12px;margin-right:5px;">
👁 Voir
</a>

<a
href="resend_campaign.php?id=<?= $m["id"] ?>"
onclick="return confirm('Renvoyer cette campagne ?')"
class="admin-btn admin-btn-success"
style="padding:6px 10px;font-size:12px;margin-right:5px;">
📨 Renvoyer
</a>

<a
href="delete_campaign.php?id=<?= $m["id"] ?>"
onclick="return confirm('Supprimer cette campagne ?')"
class="admin-btn admin-btn-danger"
style="padding:6px 10px;font-size:12px;">
🗑 Supprimer
</a>

</td>

</tr>

<?php endforeach; ?>
</tbody>

</table>
</div>
</div>

</body>

</html>