<?php
session_start();

if(!isset($_SESSION["admin"])){
    exit;
}

require_once "config.php";


$stmt = $pdo->prepare("
SELECT
    id,
    identifiant,
    sender_phone,
    statut
FROM demandes
WHERE manual_payment = 1
ORDER BY id DESC
LIMIT 50
");


$stmt->execute();


header("Content-Type: application/json");


echo json_encode(
    $stmt->fetchAll(PDO::FETCH_ASSOC)
);