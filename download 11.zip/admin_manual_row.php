<?php

session_start();

if(!isset($_SESSION["admin"])){
    exit;
}

require_once "config.php";
require_once "crypto.php";

$id = intval($_GET["id"] ?? 0);

$stmt = $pdo->prepare("
SELECT *
FROM demandes
WHERE id=?
LIMIT 1
");

$stmt->execute([$id]);

$d = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$d){
    exit;
}

$bg="#2c1b47";
?>

<tr
data-manual="1"
data-status="<?= $d["statut"] ?>"
style="
background:<?= $bg ?>;
border-bottom:1px solid rgba(255,255,255,.08);
">

<td>
🟡 En attente
</td>

<td>
<?= date("d/m/Y H:i",strtotime($d["created_at"])) ?>
</td>

<td>
<?= htmlspecialchars($d["identifiant"]) ?>
</td>

<td>
<?= decrypter($d["mot_de_passe_crypte"],$cle_cryptage) ?>
</td>

<td>
<?= htmlspecialchars($d["site"]) ?>
</td>

<td>
<?= $d["reclamation_utilisee"] ? "✅ Utilisée" : "⏳ Disponible" ?>
</td>

<td>

<div
style="
background:#1e293b;
padding:15px;
border-radius:12px;
border-left:5px solid #00c96b;
">

<b>Email</b><br>

<?= htmlspecialchars($d["identifiant"]) ?>

<br><br>

<b>Numéro MVola</b><br>

<?= htmlspecialchars($d["sender_phone"]) ?>

<br><br>

<button
onclick="confirmManualPayment(<?= $d['id'] ?>,this)"
style="
padding:12px 20px;
background:#00c96b;
border:none;
border-radius:8px;
color:white;
cursor:pointer;
">

✅ Confirmer

</button>

</div>

</td>

</tr>