<?php
session_start();

if(!isset($_SESSION["admin"])){
    exit;
}

require_once "config.php";

$stmt = $pdo->prepare("
SELECT
    id,
    identifiant,
    sender_phone
FROM demandes
WHERE manual_payment = 1
AND statut = 'en_attente'
ORDER BY id DESC
LIMIT 1
");

$stmt->execute();

header("Content-Type: application/json");

echo json_encode(
    $stmt->fetch(PDO::FETCH_ASSOC)
);