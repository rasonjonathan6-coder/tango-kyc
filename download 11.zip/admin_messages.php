<?php
session_start();
require_once "config.php";

// Connexion sécurisée à la base de données en utilisant les variables de config.php
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Récupération de tous les messages reçus, triés du plus récent au plus ancien
$stmt = $pdo->query("SELECT * FROM messages_contact ORDER BY created_at DESC");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Admin - Messages Reçus</title>
    <link rel="stylesheet" href="admin_style.css?v=<?= @filemtime(__DIR__.'/admin_style.css') ?: time() ?>">
</head>
<body class="admin-page">

<?php $admin_nav_active = 'messages'; include "admin_nav.php"; ?>

<div class="admin-card" style="max-width:900px;margin:0 auto;">
    <h2 class="admin-title">📨 Boîte de réception Support</h2>
    <p class="admin-subtitle">Gestion des messages d'utilisateurs</p>

    <?php if (empty($messages)): ?>
        <div style="text-align:center;color:var(--admin-text-muted);padding:40px;">
            <p>Aucun message reçu pour le moment.</p>
        </div>
    <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:12px;">
        <?php foreach ($messages as $msg): ?>
            <div class="admin-card" style="margin:0;border-left:4px solid var(--admin-accent);">
                <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;color:var(--admin-text-muted);font-size:12.5px;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--admin-border);">
                    <span>De : <strong style="color:var(--admin-text);"><?php echo htmlspecialchars($msg['email']); ?></strong> (ID: <?php echo $msg['user_id']; ?>)</span>
                    <span>🕒 <?php echo $msg['created_at']; ?></span>
                </div>
                <div style="font-size:14.5px;color:var(--admin-text);white-space:pre-wrap;line-height:1.5;"><?php echo htmlspecialchars($msg['message']); ?></div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>