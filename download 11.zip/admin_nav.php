<?php
/**
 * Navigation admin partagée — à inclure en haut de chaque page admin.
 * Avant l'include, définir $admin_nav_active avec l'une des valeurs :
 * 'dashboard' | 'messages' | 'broadcast' | 'campagnes' | 'retraits'
 */
$admin_nav_active = $admin_nav_active ?? '';
?>
<div class="admin-nav">
    <a href="index.php?page=admin" class="admin-nav-link <?= $admin_nav_active === 'dashboard' ? 'active' : '' ?>">
        🏠 Tableau de bord
    </a>
    <a href="admin_messages.php" class="admin-nav-link <?= $admin_nav_active === 'messages' ? 'active' : '' ?>">
        📥 Messages reçus
    </a>
    <a href="admin_broadcast.php" class="admin-nav-link <?= $admin_nav_active === 'broadcast' ? 'active' : '' ?>">
        📢 Envoyer un message
    </a>
    <a href="admin_campaigns.php" class="admin-nav-link <?= $admin_nav_active === 'campagnes' ? 'active' : '' ?>">
        📋 Campagnes
    </a>
    <a href="index.php?page=admin_retraits_mvola" class="admin-nav-link <?= $admin_nav_active === 'retraits' ? 'active' : '' ?>">
        📲 Retraits Mvola
    </a>
</div>
