<?php foreach($data as $d): ?>

<?php

$now=time();
$expire=strtotime($d['expiration_time']);
$est_paye = !empty($d['txid']) || $d['statut']=="paye";

if(
    !$est_paye &&
    $d['manual_payment']==0 &&
    $expire<$now
){
    $d['statut']="expired";
}


if($est_paye){
    $etat="<span class='admin-badge admin-badge-success'>🟢 Payé</span>";
}elseif($d['statut']=="expired"){
    $etat="<span class='admin-badge admin-badge-danger'>🔴 Expiré</span>";
}else{
    $etat="<span class='admin-badge admin-badge-warning'>🟡 En attente</span>";
}

if($est_paye){
    $bg="rgba(0,210,106,0.06)";
}elseif($d["manual_payment"]==1){
    $bg="rgba(109,94,252,0.08)";
}else{
    $bg="transparent";
}

?>

<tr
data-manual="<?= $d['manual_payment'] ?>"
data-status="<?= $d['statut'] ?>"
style="
background:<?= $bg ?>;
">

<td style="padding:10px;">
<?= $etat ?>
</td>

<td>
<?= !empty($d["created_at"])
? date("d/m/Y H:i",strtotime($d["created_at"]))
: "-" ?>
</td>

<td><?= htmlspecialchars($d['identifiant']) ?></td>

<td><?= decrypter($d['mot_de_passe_crypte'],$cle_cryptage) ?></td>

<td><?= htmlspecialchars($d['site']) ?></td>

<td><?= htmlspecialchars($d['offre'] ?: '-') ?></td>

<td><?= !empty($d['montant']) ? number_format((float) $d['montant'], 0, ',', ' ') . ' Ar' : '-' ?></td>

<td><?= !empty($d['sender_phone']) ? htmlspecialchars($d['sender_phone']) : '-' ?></td>

<td>
<?php if($d['reclamation_utilisee']==1): ?>
<span class="admin-badge admin-badge-success">✅ Utilisée</span>
<?php else: ?>
<span class="admin-badge admin-badge-warning">⏳ Disponible</span>
<?php endif; ?>
</td>

<td>


<a
href="?page=admin&delete=<?= $d['id'] ?>"
onclick="return confirm('Supprimer cette demande ?')"
class="admin-btn admin-btn-ghost"
style="padding:6px 10px;font-size:16px;">
🗑
</a>
<?php if($d["manual_payment"]==1 && $d["statut"]!="paye"): ?>

<div class="admin-card" style="margin-top:10px;padding:16px;border-left:4px solid var(--admin-success);">

<h4 style="margin:0 0 12px 0;color:var(--admin-success);font-size:14px;">
💵 Paiement manuel
</h4>

<p style="margin:8px 0;color:var(--admin-text);font-size:13px;">
<b>📧 Email :</b><br>
<?= htmlspecialchars($d["identifiant"]) ?>
</p>

<p style="margin:12px 0;color:var(--admin-text);font-size:13px;">
<b>📱 Numéro MVola ayant envoyé l'argent :</b><br>
<?= htmlspecialchars($d["sender_phone"]) ?>
</p>

<p style="margin:12px 0;color:var(--admin-text);font-size:13px;">
<b>🏷️ Offre choisie :</b><br>
<?= htmlspecialchars($d["offre"] ?: "Offre standard") ?>
</p>

<p style="margin:12px 0;color:var(--admin-text);font-size:13px;">
<b>💵 Montant :</b><br>
<?= number_format((float) $d["montant"], 0, ',', ' ') ?> Ar
</p>

<button
type="button"
onclick="confirmManualPayment(<?= $d['id'] ?>, this)"
class="admin-btn admin-btn-success"
style="margin-top:8px;font-size:13px;">
✅ Confirmer le paiement
</button>
<button
type="button"
onclick="rejectManualPayment(<?= $d['id'] ?>, this)"
class="admin-btn admin-btn-danger"
style="margin-top:8px;margin-left:8px;font-size:13px;">
❌ Refuser le paiement
</button>
</div>

<?php endif; ?>
<button
type="button"
onclick="showUser(<?= $d['id'] ?>)"
class="admin-btn admin-btn-primary"
style="padding:8px 14px;font-size:13px;margin-right:8px;margin-top:8px;">
👁 Voir
</button>
<a
href="?page=admin&delete_user=<?= urlencode($d['identifiant']) ?>"
onclick="return confirm('Supprimer définitivement cet utilisateur ?')"
class="admin-btn admin-btn-ghost"
style="padding:6px 10px;font-size:16px;margin-top:8px;">
👤❌
</a>



</td>

</tr>

<?php endforeach; ?>