<?php

session_start();

require_once "config.php";
require_once "crypto.php";

if(!isset($_SESSION["admin"])){
    exit("Accès refusé");
}

require_once "config.php";

$id = intval($_GET["id"] ?? 0);

$stmt = $pdo->prepare("
SELECT *
FROM demandes
WHERE id=?
LIMIT 1
");

$stmt->execute([$id]);

$d = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$d){

    exit("Utilisateur introuvable.");

}

?>

<h2 class="admin-title" style="font-size:18px;">
👤 Détails de la demande
</h2>

<hr style="border-color:var(--admin-border);margin:16px 0;">

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">📧 Email :</b><br>
<?= htmlspecialchars($d["identifiant"]) ?>
</p>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">🔑 Mot de passe :</b><br>
<?= decrypter($d["mot_de_passe_crypte"],$cle_cryptage) ?>
</p>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">🌐 Site :</b><br>
<?= htmlspecialchars($d["site"]) ?>
</p>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">💳 Payment ID :</b><br>
<?= htmlspecialchars($d["payment_id"]) ?>
</p>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">📌 Statut :</b><br>
<?= htmlspecialchars($d["statut"]) ?>
</p>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">💵 Paiement manuel :</b><br>

<?php

if($d["manual_payment"]){

    echo "Oui";

}else{

    echo "Non";

}

?>

</p>

<?php if(!empty($d["sender_phone"])): ?>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">📱 Numéro MVola :</b><br>

<?= htmlspecialchars($d["sender_phone"]) ?>

</p>

<?php endif; ?>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">⏳ Expiration :</b><br>

<?= htmlspecialchars($d["expiration_time"]) ?>

</p>

<p style="margin:12px 0;"><b style="color:var(--admin-text-muted);">📝 Réclamation :</b><br>

<?php

echo $d["reclamation_utilisee"] ? "Utilisée" : "Disponible";

?>

</p>