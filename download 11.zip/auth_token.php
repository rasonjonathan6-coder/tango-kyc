<?php
session_start();

$token = $_GET['token'] ?? '';

// 1. Chercher le token en BDD (vérifier qu'il existe et qu'il a moins de 2 minutes)
$user_id = verifier_et_supprimer_token_en_bdd($token); 

if ($user_id) {
    // 2. Ouvrir la session PHP dans la WebView
    $_SESSION['user_id'] = $user_id;
    
    // 3. Rediriger vers la page compte
    header("Location: /?page=compte");
    exit;
} else {
    // Si le token est invalide ou expiré
    header("Location: /?page=login&error=token_invalide");
    exit;
}