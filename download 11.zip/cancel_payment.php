<?php
session_start();

require_once "config.php";

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8",
        $db_user,
        $db_pass
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(Exception $e) {
    die($e->getMessage());
}

$pid = $_GET['pid'] ?? '';

if ($pid != '') {

    $pdo->beginTransaction();

    // Libérer le wallet USDT
    $pdo->prepare("
        UPDATE wallets
        SET
            status='free',
            reserved_payment_id=NULL,
            reserved_at=NULL,
            last_used_at=NOW()
        WHERE reserved_payment_id=?
    ")->execute([$pid]);

    // Supprimer la demande si elle est encore en attente
    $pdo->prepare("
        DELETE FROM demandes
        WHERE payment_id=?
        AND statut='en_attente'
    ")->execute([$pid]);

    $pdo->commit();
}

header("Location: index.php?page=compte");
exit;