<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if(!isset($_SESSION["admin"])){
    exit;
}

require_once "config.php";

header("Content-Type: application/json");

// ================= STATISTIQUES ADMIN (identiques à index_46.php) =================

$totalPayes = $pdo->query("
SELECT COUNT(*)
FROM demandes
WHERE statut='paye'
")->fetchColumn();

// Nombre total de demandes, toutes catégories confondues (identique à index.php)
$totalDemandes = $pdo->query("
SELECT COUNT(*)
FROM demandes
")->fetchColumn();

$totalAttente = $pdo->query("
SELECT COUNT(*)
FROM demandes
WHERE statut='en_attente'
")->fetchColumn();

$totalManuel = $pdo->query("
SELECT COUNT(*)
FROM demandes
WHERE manual_payment=1
AND statut!='paye'
")->fetchColumn();

// 📲 Retraits Mvola en attente de confirmation (table créée par le module portefeuille)
try {
    $totalRetraitsAttente = $pdo->query("
        SELECT COUNT(*)
        FROM retraits_mvola
        WHERE statut='en_attente'
    ")->fetchColumn();
} catch (Exception $e) {
    $totalRetraitsAttente = 0;
}

$totalExpires = $pdo->query("
SELECT COUNT(*)
FROM demandes
WHERE expiration_time < NOW()
AND statut!='paye'
")->fetchColumn();

$totalUsers = $pdo->query("
SELECT COUNT(*)
FROM users
")->fetchColumn();

// ================= TABLEAU DES DEMANDES =================
// Réutilise exactement le même include que la page Admin pour rester identique.
$data = $pdo->query("SELECT * FROM demandes ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

ob_start();
include "admin_table.php";
$tableHtml = ob_get_clean();

// ================= NOUVEAUX UTILISATEURS (5 derniers inscrits) =================

$nouveauxUtilisateurs = $pdo->query("
SELECT email, created_at, verified
FROM users
ORDER BY created_at DESC
LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

ob_start();

if(empty($nouveauxUtilisateurs)){
    echo '<p style="color:rgba(255,255,255,.6);margin:0;">Aucun utilisateur inscrit pour le moment.</p>';
} else {
    echo '<div style="display:flex;flex-direction:column;gap:10px;">';
    foreach($nouveauxUtilisateurs as $u){
        $badgeBg    = $u['verified'] ? '#0f3d2e' : '#6b5900';
        $badgeColor = $u['verified'] ? '#4ade80' : '#fde047';
        $badgeText  = $u['verified'] ? '✅ Vérifié' : '⏳ Non vérifié';
        $date       = $u['created_at'] ? date("d/m/Y H:i", strtotime($u['created_at'])) : '-';

        echo '<div style="
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            background:rgba(255,255,255,.05);
            border:1px solid rgba(255,255,255,.1);
            border-radius:10px;
            padding:12px 15px;
            flex-wrap:wrap;
        ">
            <div style="display:flex;align-items:center;gap:10px;min-width:0;">
                <span style="font-size:20px;">👤</span>
                <span style="font-weight:600;overflow-wrap:anywhere;">' . htmlspecialchars($u['email']) . '</span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
                <span style="
                    font-size:11.5px;
                    font-weight:bold;
                    padding:4px 10px;
                    border-radius:999px;
                    background:' . $badgeBg . ';
                    color:' . $badgeColor . ';
                ">' . $badgeText . '</span>
                <span style="font-size:12.5px;color:rgba(255,255,255,.55);white-space:nowrap;">' . $date . '</span>
            </div>
        </div>';
    }
    echo '</div>';
}

$nouveauxUtilisateursHtml = ob_get_clean();

// ================= LISTE COMPLETE DES UTILISATEURS =================

$listeUtilisateurs = $pdo->query("
SELECT email, created_at, verified
FROM users
ORDER BY created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

ob_start();

if(empty($listeUtilisateurs)){
    echo '<p style="color:rgba(255,255,255,.6);margin:0;">Aucun utilisateur inscrit pour le moment.</p>';
} else {
    foreach($listeUtilisateurs as $u){
        $badgeBg    = $u['verified'] ? '#0f3d2e' : '#6b5900';
        $badgeColor = $u['verified'] ? '#4ade80' : '#fde047';
        $badgeText  = $u['verified'] ? '✅ Vérifié' : '⏳ Non vérifié';
        $date       = $u['created_at'] ? date("d/m/Y H:i", strtotime($u['created_at'])) : '-';

        echo '<div class="user-row-admin" style="
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            background:rgba(255,255,255,.05);
            border:1px solid rgba(255,255,255,.1);
            border-radius:10px;
            padding:12px 15px;
            flex-wrap:wrap;
        ">
            <div style="display:flex;align-items:center;gap:10px;min-width:0;">
                <span style="font-size:20px;">👤</span>
                <span style="font-weight:600;overflow-wrap:anywhere;">' . htmlspecialchars($u['email']) . '</span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
                <span style="
                    font-size:11.5px;
                    font-weight:bold;
                    padding:4px 10px;
                    border-radius:999px;
                    background:' . $badgeBg . ';
                    color:' . $badgeColor . ';
                ">' . $badgeText . '</span>
                <span style="font-size:12.5px;color:rgba(255,255,255,.55);white-space:nowrap;">' . $date . '</span>
            </div>
        </div>';
    }
}

$listeUtilisateursHtml = ob_get_clean();

// ================= REPONSE JSON =================

echo json_encode([
    "totalPayes"               => $totalPayes,
    "totalDemandes"            => $totalDemandes,
    "totalAttente"              => $totalAttente,
    "totalManuel"               => $totalManuel,
    "totalRetraitsAttente"      => $totalRetraitsAttente,
    "totalExpires"              => $totalExpires,
    "totalUsers"                => $totalUsers,
    "table"                     => $tableHtml,
    "nouveauxUtilisateursHtml"  => $nouveauxUtilisateursHtml,
    "listeUtilisateursHtml"     => $listeUtilisateursHtml,
]);
