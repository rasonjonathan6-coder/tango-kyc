<?php

header("Content-Type: application/json");

require_once "config.php";

$paymentId = $_GET["payment_id"] ?? "";

if($paymentId === ""){

    echo json_encode([
        "success" => false,
        "message" => "payment_id manquant."
    ]);

    exit;
}

/* On ne renvoie que ce qui est nécessaire au polling côté client :
   - statut='paye' + manual_status=3  => paiement confirmé par l'admin
   - manual_payment=0                 => demande refusée par l'admin
   - sinon                            => toujours en attente */
$stmt = $pdo->prepare("
    SELECT statut, manual_payment, manual_status
    FROM demandes
    WHERE payment_id = ?
    LIMIT 1
");

$stmt->execute([$paymentId]);

$demande = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$demande){

    echo json_encode([
        "success" => false,
        "message" => "Demande introuvable."
    ]);

    exit;
}

echo json_encode([
    "success"        => true,
    "statut"         => $demande["statut"],
    "manual_payment" => (int) $demande["manual_payment"],
    "manual_status"  => (int) $demande["manual_status"]
]);
