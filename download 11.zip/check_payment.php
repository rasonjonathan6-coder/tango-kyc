<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
ini_set('display_errors',1);
error_reporting(E_ALL);

header("Content-Type:text/plain");
require_once "config.php";
require_once "mvola/oauth.php";
require_once "mvola/config_mvola.php";
require_once "mail.php";
require_once "release_wallets.php";
function validerPaiement(PDO $pdo, $paymentId){

    $pdo->prepare("
        UPDATE demandes
        SET
            statut='paye',
            mvola_status='completed'
        WHERE payment_id=?
    ")->execute([$paymentId]);

    // Libère le wallet
    releaseWallet($pdo, $paymentId);

    // Récupère l'email du client
    $stmt = $pdo->prepare("
        SELECT identifiant
        FROM demandes
        WHERE payment_id=?
        LIMIT 1
    ");

    $stmt->execute([$paymentId]);

    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if($client){

    require_once "payment_success_mail.php";

sendPaymentSuccessMail($pdo, $paymentId);

    }

}

header("Content-Type:text/plain");

$paymentId=$_GET["pid"]??"";

if($paymentId=="")
{
    exit("unpaid");
}

$stmt=$pdo->prepare("
SELECT *
FROM demandes
WHERE payment_id=?
LIMIT 1
");

$stmt->execute([$paymentId]);

$d=$stmt->fetch(PDO::FETCH_ASSOC);

if(!$d)
{
    exit("unpaid");
}
file_put_contents(
    __DIR__ . "/debug_status.txt",
    date("H:i:s") . " | statut=" . $d["statut"] . PHP_EOL,
    FILE_APPEND
);
if($d["statut"]=="paye")
{
    exit("paid");
}

if($d["statut"]=="expired")
{
    exit("expired");
}

if(empty($d["server_correlation_id"]))
{
    exit("pending");
}

$token=getAccessToken();

$url=MVOLA_BASE_URL.
"/status/".
$d["server_correlation_id"];

$headers=[

"Authorization: Bearer ".$token,

"Version: ".MVOLA_VERSION,

"X-CorrelationID: ".uniqid(),

"UserAccountIdentifier: msisdn;".MVOLA_MERCHANT_MSISDN,

"partnerName: ".MVOLA_PARTNER_NAME,

"Cache-Control: no-cache"

];

$ch=curl_init($url);
curl_setopt_array($ch,[

CURLOPT_RETURNTRANSFER=>true,

CURLOPT_HTTPHEADER=>$headers,

CURLOPT_TIMEOUT=>30,

CURLOPT_CONNECTTIMEOUT=>10

]);

$response=curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);

$error = curl_error($ch);

file_put_contents(

__DIR__."/mvola/status.log",

date("Y-m-d H:i:s").PHP_EOL.

"HTTP=".$http.PHP_EOL.

($error ?: "OK").PHP_EOL.

$response.PHP_EOL.

"--------------------------------".PHP_EOL,

FILE_APPEND

);

curl_close($ch);
if($error){

    exit("pending");

}

if($http!=200){

    exit("pending");

}
$json=json_decode($response,true);
$status = "";

if (isset($json["status"])) {
    $status = strtolower(trim($json["status"]));
}
switch($status){
case "completed":

    validerPaiement($pdo, $paymentId);

    exit("paid");
case "failed":

    exit("failed");

case "cancelled":

    exit("cancelled");

case "expired":

    exit("expired");

default:

    exit("pending");

}