<?php
ini_set('display_errors',1);
error_reporting(E_ALL);

header("Content-Type:text/plain");
require_once "mail.php";
$pdo = new PDO(
    "mysql:host=localhost;dbname=deblocagetangoco;charset=utf8",
    "deblocagetangoco",
    "Ambatovy.M94743",
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
);

$pid = $_GET['pid'] ?? '';
if(!$pid){
    echo "unpaid";
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM demandes WHERE payment_id=? LIMIT 1");
$stmt->execute([$pid]);
$demande = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$demande){
    echo "unpaid";
    exit;
}
// Si le paiement est expiré
if($demande['statut'] === "expired"){
    echo "expired";
    exit;
}
if($demande['statut'] === "paye"){
    echo "paid";
    exit;
}

$wallet = strtolower(trim($demande['wallet_address']));
$montant_attendu = (float)$demande['montant_usdt'];
$dateCreation = strtotime($demande['created_at']);
$expiration = strtotime($demande['expiration_time']);



if (time() >= $expiration && $demande['statut'] === "en_attente") {

    $pdo->beginTransaction();

    $pdo->prepare("
        UPDATE demandes
        SET statut='expired'
        WHERE payment_id=?
    ")->execute([$pid]);

    $pdo->prepare("
        UPDATE wallets
        SET status='free',
            reserved_payment_id=NULL,
            reserved_at=NULL,
            last_used_at=NOW()
        WHERE reserved_payment_id=?
    ")->execute([$pid]);

    $pdo->commit();

    echo "expired";
    exit;
}
$usdtContract = "0x55d398326f99059ff775485246999027b3197955";

$url = "https://bnb-mainnet.g.alchemy.com/v2/vY-9fLEDoV5HZYddV3x_L";

$data = [
    "jsonrpc" => "2.0",
    "id" => 1,
    "method" => "alchemy_getAssetTransfers",
    "params" => [[
        "fromBlock" => "0x0",
        "toAddress" => $wallet,
        "contractAddresses" => [$usdtContract],
        "category" => ["erc20"],
        "withMetadata" => true
    ]]
];

$options = [
    "http" => [
        "header"  => "Content-Type: application/json\r\n",
        "method"  => "POST",
        "content" => json_encode($data),
        "timeout" => 10
    ]
];

$response = @file_get_contents($url,false,stream_context_create($options));

if(!$response){
    echo "unpaid";
    exit;
}

$result = json_decode($response,true);
$transfers = $result["result"]["transfers"] ?? [];

if(empty($transfers)){
    echo "unpaid";
    exit;
}

foreach($transfers as $tx){

    $txTime = isset($tx["metadata"]["blockTimestamp"])
        ? strtotime($tx["metadata"]["blockTimestamp"])
        : 0;

    if($txTime < $dateCreation){
        continue;
    }

    $txid = $tx["hash"] ?? '';
    if(!$txid) continue;

    // anti double spend
    $check = $pdo->prepare("SELECT id FROM demandes WHERE txid=? LIMIT 1");
    $check->execute([$txid]);
    if($check->fetch()){
        continue;
    }

$amount = (float)$tx["value"];

    $tolerance = 0.05;

    $precision_ok =
        $amount >= ($montant_attendu - $tolerance) &&
        $amount <= ($montant_attendu + $tolerance);

    $wallet_ok = isset($tx["toAddress"]) &&
        strtolower($tx["toAddress"]) === $wallet;

    $contract_ok =
        isset($tx["rawContract"]["address"]) &&
        strtolower($tx["rawContract"]["address"]) === strtolower($usdtContract);

    if($precision_ok && $wallet_ok && $contract_ok){

        $update = $pdo->prepare("
            UPDATE demandes
            SET statut='paye',txid=?
            WHERE payment_id=?
                 ");
        $update->execute([$txid, $pid]);
// Envoi email confirmation paiement USDT

require_once "payment_success_mail.php";

sendPaymentSuccessMail($pdo, $pid);
        // IMPORTANT: sécuriser libération wallet
        $pdo->prepare("
            UPDATE wallets
            SET status='free',
                reserved_payment_id=NULL,
                reserved_at=NULL,
                last_used_at=NOW()
            WHERE address=? AND reserved_payment_id=?
        ")->execute([$wallet, $pid]);

        echo "paid";
        exit;
    }
}

echo "unpaid";