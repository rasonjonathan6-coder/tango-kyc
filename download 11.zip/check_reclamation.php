<?php
session_start();

ini_set('display_errors', 0);
error_reporting(0);

header('Content-Type: application/json; charset=utf-8');

require_once 'config.php';

try {

    $email = trim(strtolower($_POST['email_reclamation'] ?? ''));

    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        echo json_encode(["status"=>"error","message"=>"Email invalide"]);
        exit;
    }


    $data = null;

    // 🩹 CORRECTIF : appel venant du bouton "Non" ("La discussion support
    // Tango a-t-elle été ouverte ?"). Pour l'offre Essai unique, on ne
    // vérifie plus le paiement : un essai gratuit n'a jamais de paiement,
    // donc exiger statut='paye' bloquait systématiquement ce flux. On se
    // contente ici de retrouver une demande Essai correspondant à l'email,
    // sans autre condition (ni statut, ni reclamation_utilisee).
    if(!empty($_POST['bypass_paiement_essai'])){
        $stmtEssai = $pdo->prepare("
SELECT id
FROM demandes
WHERE identifiant = ?
AND offre = 'Essai'
LIMIT 1
");
        $stmtEssai->execute([$email]);
        $data = $stmtEssai->fetch(PDO::FETCH_ASSOC);
    }

    // Vérifier paiement (flux normal, inchangé)
    //
    // 🩹 CORRECTIF : on applique désormais la même règle que dans got.php —
    //  - Essai unique (offre = 'Essai') : utilisable tant que reclamation_utilisee = 0.
    //  - 24h / 7j / 30j (offre <> 'Essai') : utilisable uniquement tant que
    //    l'abonnement est encore actif (abonnement_fin > NOW()). Un abonnement
    //    expiré ne doit plus permettre d'ouvrir une réclamation sans paiement.
    if(!$data){
        $stmt = $pdo->prepare("
SELECT id
FROM demandes
WHERE identifiant = ?
AND statut = 'paye'
AND reclamation_utilisee = 0
AND (
    offre = 'Essai'
    OR (offre <> 'Essai' AND abonnement_fin IS NOT NULL AND abonnement_fin > NOW())
)
LIMIT 1
");
        $stmt->execute([$email]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if(!$data){

        echo json_encode([
            "status" => "error",
            "message" => "Aucun paiement confirmé"
        ]);
        exit;
    }

    // Le paiement existe → on le marque comme utilisé
    $pdo->prepare("
UPDATE demandes
SET reclamation_utilisee=1
WHERE id=?
")->execute([$data['id']]);
    $_SESSION['reclamation_ok'] = true;

    // 🩹 CORRECTIF (session perdue en WebView) : certaines WebView Android
    // n'envoient pas fiablement le même cookie de session entre l'appel
    // fetch() vers ce fichier et la navigation complète qui suit vers
    // got.php. On ne dépend donc plus uniquement de $_SESSION pour valider
    // l'accès côté got.php : on transmet aussi l'id de la demande, que
    // got.php revérifiera lui-même en base (id + statut paye +
    // reclamation_utilisee=1), indépendamment de la session.
    echo json_encode([
        "status" => "success",
        "redirect" => "got.php?mode=reclamation&id=" . (int)$data['id']
    ]);
    exit;

} catch(Exception $e){
    echo json_encode([
        "status" => "error",
        "message" => "Erreur serveur"
    ]);
    exit;
}
