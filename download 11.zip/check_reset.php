<?php
session_start();
require_once 'config.php';

$message = "";
$is_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données reçues
    $email    = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $otp      = trim($_POST['otp'] ?? '');
    $raw_pass = $_POST['new_pass'] ?? '';

    if (!$email || empty($otp) || empty($raw_pass)) {
        $message = "Veuillez remplir tous les champs correctement.";
    } else {
        try {
            $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Vérification de l'OTP et de sa validité temporelle via la BASE
            // DE DONNÉES (c'est là qu'index.php enregistre réellement le
            // code lors de l'étape "Envoyer le code" : UPDATE users SET
            // verify_code = ?, code_expire = ? WHERE email = ?).
            // ⚠️ Avant : ce script comparait avec $_SESSION['verify_code'],
            // qui appartient en fait au flux d'inscription (autre formulaire)
            // et n'est jamais rempli par "mot de passe oublié" — d'où le
            // rejet quasi systématique du bon code.
            $stmt = $pdo->prepare("SELECT id, verify_code, code_expire FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (
                $user &&
                !empty($user['verify_code']) &&
                !empty($user['code_expire']) &&
                $otp === (string)$user['verify_code'] &&
                strtotime($user['code_expire']) > time()
            ) {

                // Hachage du nouveau mot de passe
                $new_pass = password_hash($raw_pass, PASSWORD_DEFAULT);

                // Mise à jour du mot de passe en base de données, et on
                // invalide le code tout de suite après usage pour qu'il ne
                // puisse pas être réutilisé (au lieu d'un unset() de session
                // qui ne touchait pas la vraie source du code).
                $upd = $pdo->prepare("UPDATE users SET password = ?, verify_code = NULL, code_expire = NULL WHERE email = ?");
                $upd->execute([$new_pass, $email]);

                $message = "Mot de passe mis à jour avec succès !";
                $is_success = true;

            } else {
                // Reste identique à votre message initial si le code ne correspond pas ou est expiré
                $message = "Code invalide ou expiré.";
            }
        } catch (Exception $e) {
            // Sécurité : Ne pas exposer les détails de l'erreur SQL
            $message = "Une erreur est survenue lors du traitement.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background: radial-gradient(circle at 80% 20%, #ff057c 0%, #32004f 50%, #03001e 100%); 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin: 0; 
        }
        .card { 
            background: rgba(255,255,255,0.03); 
            backdrop-filter: blur(25px); 
            border: 1px solid rgba(255,255,255,0.12); 
            border-radius: 30px; 
            width: 100%; 
            max-width: 400px; 
            padding: 40px; 
            text-align: center; 
            color: white; 
        }
        .btn-back { 
            display: block; 
            margin-top: 25px; 
            padding: 15px; 
            border-radius: 12px; 
            background: linear-gradient(90deg, #ff0055 0%, #b000cd 100%); 
            color: white; 
            text-decoration: none; 
            font-weight: bold; 
        }
        h2 { 
            margin-bottom: 20px; 
        }
        .icon { 
            font-size: 50px; 
            margin-bottom: 15px; 
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon"><?= $is_success ? "✅" : "❌" ?></div>
        <h2><?= $is_success ? "Succès" : "Erreur" ?></h2>
        <p><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
        <a href="index.php" class="btn-back">Retour à la connexion</a>
    </div>
</body>
</html>