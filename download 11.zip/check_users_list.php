<?php
// Endpoint JSON utilisé par la section "Liste des utilisateurs" de l'Espace Admin
// pour se synchroniser toutes les 3 secondes sans recharger la page.

session_start();

if (!isset($_SESSION["admin"])) {
    http_response_code(403);
    header("Content-Type: application/json");
    echo json_encode(["error" => "Accès refusé"]);
    exit;
}

require_once "config.php";

$listeUtilisateurs = $pdo->query("
SELECT email, created_at, verified
FROM users
ORDER BY created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

ob_start();
if (empty($listeUtilisateurs)) {
    ?>
    <p style="color:rgba(255,255,255,.6);margin:0;">Aucun utilisateur inscrit pour le moment.</p>
    <?php
} else {
    foreach ($listeUtilisateurs as $u) {
        ?>
        <div class="user-row-admin" style="
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            background:rgba(255,255,255,.05);
            border:1px solid rgba(255,255,255,.1);
            border-radius:10px;
            padding:12px 15px;
            flex-wrap:wrap;
        ">
            <div style="display:flex;align-items:center;gap:10px;min-width:0;">
                <span style="font-size:20px;">👤</span>
                <span style="font-weight:600;overflow-wrap:anywhere;"><?= htmlspecialchars($u['email']) ?></span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
                <span style="
                    font-size:11.5px;
                    font-weight:bold;
                    padding:4px 10px;
                    border-radius:999px;
                    background:<?= $u['verified'] ? '#0f3d2e' : '#6b5900' ?>;
                    color:<?= $u['verified'] ? '#4ade80' : '#fde047' ?>;
                ">
                    <?= $u['verified'] ? '✅ Vérifié' : '⏳ Non vérifié' ?>
                </span>
                <span style="font-size:12.5px;color:rgba(255,255,255,.55);white-space:nowrap;">
                    <?= $u['created_at'] ? date("d/m/Y H:i", strtotime($u['created_at'])) : '-' ?>
                </span>
            </div>
        </div>
        <?php
    }
}
$html = ob_get_clean();

header("Content-Type: application/json");
echo json_encode([
    "totalUsers" => count($listeUtilisateurs),
    "html" => $html
]);
