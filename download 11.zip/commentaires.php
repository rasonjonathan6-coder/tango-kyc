<?php
// 🔒 Mêmes réglages de sécurité de session que index.php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');

session_start();
header('Content-Type: application/json; charset=utf-8');
header("X-Robots-Tag: noindex, nofollow, noarchive", true);

// ✅ Force l'encodage UTF-8 partout dans ce script (indépendamment de la
// configuration du serveur), pour éviter tout accent mal affiché (mojibake).
mb_internal_encoding('UTF-8');

require_once 'config.php';

// ✅ S'assure que la connexion PDO communique bien en UTF-8 avec la base,
// même si config.php ne le précise pas déjà (sinon les accents stockés en
// utf8mb4 peuvent ressortir corrompus).
$pdo->exec("SET NAMES 'utf8mb4'");

// Endpoint public : affiché sur le dashboard, aucune authentification requise.
$stmt = $pdo->prepare("
    SELECT email, message, created_at
    FROM commentaires
    WHERE visible = 1
    ORDER BY created_at DESC
    LIMIT 20
");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Masque l'email du client pour préserver sa confidentialité (ex: jo***@gmail.com)
function masquerEmail($email){
    if(!$email || strpos($email, '@') === false){
        return "Client vérifié";
    }
    list($nom, $domaine) = explode('@', $email, 2);
    $visible = mb_substr($nom, 0, 2, 'UTF-8');
    return $visible . "***@" . $domaine;
}

$commentaires = [];
foreach($rows as $row){
    $commentaires[] = [
        "auteur"  => masquerEmail($row["email"]),
        "message" => $row["message"],
        "date"    => $row["created_at"] ? date("d/m/Y", strtotime($row["created_at"])) : "",
    ];
}

// ✅ JSON_UNESCAPED_UNICODE : les caractères accentués (é, à, ç...) sortent
// tels quels dans le JSON, au lieu d'être échappés en \uXXXX.
echo json_encode([
    "success"      => true,
    "commentaires" => $commentaires
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);