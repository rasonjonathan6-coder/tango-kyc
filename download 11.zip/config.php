<?php
$mot_de_passe_admin = "Ambatovy.M93743";
$cle_cryptage = "UneCleTresSecreteEtLonguePourSecuriser!";
$db_host = "sql111.infinityfree.com";
$db_name = "if0_42614432_Tango";
$db_user = "if0_42614432";
$db_pass = "Jirama501";

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);   
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(Exception $e) {
    die("Erreur base de données : " . $e->getMessage());
}

$site_url = "https://deblocagetango.com";

$google_client_id = "286731442242-gutjdvpd6h03dlnqlfbn1431a80oe82m.apps.googleusercontent.com";
$google_client_secret = "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";
$google_redirect_uri = $site_url . "/index.php?page=google_callback";


// Gmail API OAuth 2.0 — remplacer uniquement les valeurs entre apostrophes.
$tango_gmail_client_id = '439838119377-5m51itd2nsqd7btagkvipm98aud4mklc.apps.googleusercontent.com';
$tango_gmail_client_secret = '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';
$tango_gmail_redirect_uri = $site_url . '/gmail_callback.php';
$tango_gmail_user = 'estrellahvanessa@gmail.com';
$tango_gmail_refresh_token = '';



?>