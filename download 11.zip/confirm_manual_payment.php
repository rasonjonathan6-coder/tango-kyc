<?php

session_start();

if(!isset($_SESSION["admin"])){
    exit("Accès refusé");
}

require_once "config.php";
require_once "mail.php";
require_once "release_wallets.php";

$id = intval($_GET["id"] ?? 0);

if($id <= 0){
    exit("ID invalide");
}

$stmt = $pdo->prepare("
SELECT payment_id
FROM demandes
WHERE id=?
LIMIT 1
");

$stmt->execute([$id]);

$demande = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$demande){
    exit("Demande introuvable");
}

$paymentId = $demande["payment_id"];
$stmt = $pdo->prepare("
SELECT statut
FROM demandes
WHERE payment_id=?
LIMIT 1
");

$stmt->execute([$paymentId]);

$info = $stmt->fetch(PDO::FETCH_ASSOC);

if($info["statut"] == "paye"){
    exit("Ce paiement est déjà confirmé.");
}
// Paiement validé
$pdo->prepare("
UPDATE demandes
SET
    statut='paye',
    txid='MANUEL',
    mvola_status='completed'
WHERE payment_id=?
")->execute([$paymentId]);

// Libérer le wallet
releaseWallet($pdo, $paymentId);

// Récupérer l'email
$stmt = $pdo->prepare("
SELECT identifiant
FROM demandes
WHERE payment_id=?
LIMIT 1
");

$stmt->execute([$paymentId]);

$client = $stmt->fetch(PDO::FETCH_ASSOC);

if($client){

require_once "payment_success_mail.php";

sendPaymentSuccessMail($pdo, $paymentId);

}

header("Location:?page=admin");
exit;