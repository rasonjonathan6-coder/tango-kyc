<?php

function crypter($d, $k)
{
    $iv = openssl_random_pseudo_bytes(
        openssl_cipher_iv_length('aes-256-cbc')
    );

    return base64_encode(
        openssl_encrypt($d,'aes-256-cbc',$k,0,$iv)
        .'::'.$iv
    );
}

function decrypter($d, $k)
{
    list($e,$iv)=explode(
        '::',
        base64_decode($d),
        2
    );

    return openssl_decrypt(
        $e,
        'aes-256-cbc',
        $k,
        0,
        $iv
    );
}