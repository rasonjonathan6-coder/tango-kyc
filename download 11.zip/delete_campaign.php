<?php

session_start();

if(!isset($_SESSION["admin"])){
    exit;
}

require_once "config.php";

$id = intval($_GET["id"] ?? 0);

$pdo->prepare("
DELETE FROM messages_admin
WHERE id=?
")->execute([$id]);

header("Location: admin_campaigns.php");
exit;