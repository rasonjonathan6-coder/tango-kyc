<?php
session_start();
require_once "config.php";

$order_number = $_GET['order_number'] ?? ($_GET['txn_id'] ?? '');

$demande = null;

if ($order_number !== '') {
    $stmt = $pdo->prepare("SELECT * FROM demandes WHERE payment_id = ? LIMIT 1");
    $stmt->execute([$order_number]);
    $demande = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Paiement échoué</title>
<style>
*{box-sizing:border-box;}
body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    font-family:Inter,system-ui,Arial,sans-serif;
    background:linear-gradient(135deg,#111827,#1e3a8a,#7f1d1d);
    padding:20px;
}
.card{
    background:rgba(17,24,39,.85);
    border:1px solid rgba(255,255,255,.1);
    border-radius:28px;
    padding:40px 30px;
    max-width:420px;
    width:100%;
    text-align:center;
    box-shadow:0 25px 60px rgba(0,0,0,.4);
}
.icon{
    width:78px;
    height:78px;
    margin:0 auto 20px;
    border-radius:50%;
    background:linear-gradient(135deg,#ef4444,#991b1b);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:38px;
    color:white;
}
h1{color:#fff;font-size:22px;margin:0 0 10px;}
p{color:rgba(255,255,255,.7);font-size:14px;line-height:1.6;margin:0 0 25px;}
.btn{
    display:inline-block;
    background:#e5e7eb;
    color:#374151;
    text-decoration:none;
    font-weight:600;
    padding:14px 28px;
    border-radius:16px;
    margin:6px;
}
.btn-retry{
    display:inline-block;
    background:linear-gradient(135deg,#ef4444,#991b1b);
    color:white;
    text-decoration:none;
    font-weight:600;
    padding:14px 28px;
    border-radius:16px;
    margin:6px;
    box-shadow:0 10px 25px rgba(239,68,68,.3);
}
</style>
</head>
<body>

<div class="card">
    <div class="icon">✕</div>
    <h1>Paiement non abouti</h1>
    <p>Votre paiement a été annulé ou n'a pas pu être confirmé. Aucun montant n'a été débité de votre part. Vous pouvez réessayer à tout moment.</p>

    <a href="index.php?page=compte" class="btn-retry">Réessayer</a>
    <a href="index.php?page=compte" class="btn">Retour</a>
</div>

</body>
</html>
