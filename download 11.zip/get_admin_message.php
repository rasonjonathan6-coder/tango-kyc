<?php

session_start();

require_once "config.php";

if(!isset($_SESSION["user_id"])){
    exit;
}

$userId = $_SESSION["user_id"];

// Récupère le dernier statut du user
$stmt = $pdo->prepare("
SELECT *
FROM messages_admin
WHERE afficher_dashboard=1
AND (
    cible='tous'
    OR cible=?
)
AND id NOT IN(

SELECT message_id
FROM messages_admin_lus
WHERE user_id=?

)

ORDER BY id DESC
LIMIT 1
");

$stmt->execute([

    $statut,

    $userId

]);

$msg = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($msg);