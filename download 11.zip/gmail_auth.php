<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gmail_service.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['admin'])) { http_response_code(403); exit('Accès admin requis'); }
$c=['client_id'=>getenv('TANGO_GMAIL_CLIENT_ID')?:'','redirect_uri'=>getenv('TANGO_GMAIL_REDIRECT_URI')?:''];
if($c['client_id']==='' || $c['redirect_uri']==='') exit('Client ID ou Redirect URI Gmail manquant');
$state=bin2hex(random_bytes(32));
$_SESSION['gmail_oauth_state_hash']=hash('sha256',$state);
$params=http_build_query(['client_id'=>$c['client_id'],'redirect_uri'=>$c['redirect_uri'],'response_type'=>'code','access_type'=>'offline','prompt'=>'consent','scope'=>'https://www.googleapis.com/auth/gmail.modify','state'=>$state]);
header('Location: https://accounts.google.com/o/oauth2/v2/auth?'.$params); exit;
