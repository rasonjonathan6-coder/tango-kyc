<?php
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['admin'])) { http_response_code(403); exit('Accès admin requis'); }
$state=(string)($_GET['state']??'');
if ($state==='' || empty($_SESSION['gmail_oauth_state_hash']) || !hash_equals($_SESSION['gmail_oauth_state_hash'],hash('sha256',$state))) exit('État OAuth invalide');
$code=(string)($_GET['code']??''); if($code==='') exit('Code OAuth manquant');
$data=http_build_query(['code'=>$code,'client_id'=>getenv('TANGO_GMAIL_CLIENT_ID'),'client_secret'=>getenv('TANGO_GMAIL_CLIENT_SECRET'),'redirect_uri'=>getenv('TANGO_GMAIL_REDIRECT_URI'),'grant_type'=>'authorization_code']);
$ch=curl_init('https://oauth2.googleapis.com/token'); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$data,CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],CURLOPT_SSL_VERIFYPEER=>true]); $raw=curl_exec($ch); $codeHttp=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
$json=json_decode($raw?:'',true); if($codeHttp<200||$codeHttp>=300||empty($json['refresh_token'])) exit('OAuth échoué ou refresh token absent. Révoquez puis recommencez.');
unset($_SESSION['gmail_oauth_state_hash']);
header('Content-Type:text/plain; charset=utf-8'); echo "OAuth Gmail réussi.\n\nRefresh Token à placer dans TANGO_GMAIL_REFRESH_TOKEN (jamais dans Git ou HTML):\n".$json['refresh_token'];
