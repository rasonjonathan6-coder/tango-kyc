<?php
/** Gmail REST OAuth helper. Tokens are read from environment variables only. */
function tango_gmail_config(): array {
    $cfg = [
        'client_id' => getenv('TANGO_GMAIL_CLIENT_ID') ?: '',
        'client_secret' => getenv('TANGO_GMAIL_CLIENT_SECRET') ?: '',
        'redirect_uri' => getenv('TANGO_GMAIL_REDIRECT_URI') ?: '',
        'refresh_token' => getenv('TANGO_GMAIL_REFRESH_TOKEN') ?: '',
        'user' => getenv('TANGO_GMAIL_USER') ?: 'me',
        'support_email' => 'rasonjonathan6@gmail.com', // Destinataire de test temporaire
    ];
    foreach (['client_id','client_secret','redirect_uri','refresh_token'] as $key) {
        if ($cfg[$key] === '') throw new RuntimeException('Configuration Gmail manquante: ' . $key);
    }
    return $cfg;
}
function tango_gmail_http(string $url, string $method='GET', ?string $body=null, array $headers=[]): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CUSTOMREQUEST=>$method, CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_HTTPHEADER=>$headers]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if ($raw === false || $err) throw new RuntimeException('Gmail HTTP: ' . $err);
    $json = json_decode($raw, true);
    if ($code < 200 || $code >= 300) throw new RuntimeException('Gmail API ' . $code . ': ' . ($json['error']['message'] ?? $raw));
    return is_array($json) ? $json : [];
}
function tango_gmail_access_token(): string {
    $c = tango_gmail_config();
    $data = http_build_query(['client_id'=>$c['client_id'],'client_secret'=>$c['client_secret'],'refresh_token'=>$c['refresh_token'],'grant_type'=>'refresh_token']);
    $result = tango_gmail_http('https://oauth2.googleapis.com/token','POST',$data,['Content-Type: application/x-www-form-urlencoded']);
    if (empty($result['access_token'])) throw new RuntimeException('Jeton Gmail absent');
    return $result['access_token'];
}
function tango_gmail_api(string $path, string $method='GET', ?array $json=null): array {
    $body = $json === null ? null : json_encode($json, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $headers = ['Authorization: Bearer '.tango_gmail_access_token(), 'Accept: application/json'];
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    return tango_gmail_http('https://gmail.googleapis.com/gmail/v1/users/me/'.$path, $method, $body, $headers);
}
function tango_gmail_b64url(string $value): string { return rtrim(strtr(base64_encode($value), '+/', '-_'), '='); }
function tango_gmail_header(string $name, string $value): string { return $name . ': ' . $value . "\r\n"; }
function tango_gmail_send(string $to, string $subject, string $text, ?string $threadId=null): array {
    $c = tango_gmail_config();
    $from = $c['user'];
    $raw = tango_gmail_header('From', $from) . tango_gmail_header('To', $to) . tango_gmail_header('Subject', $subject) . tango_gmail_header('MIME-Version','1.0') . tango_gmail_header('Content-Type','text/plain; charset=UTF-8') . "\r\n" . $text;
    $payload = ['raw'=>tango_gmail_b64url($raw)];
    if ($threadId) $payload['threadId'] = $threadId;
    return tango_gmail_api('messages/send','POST',$payload);
}
function tango_gmail_get_message(string $id): array { return tango_gmail_api('messages/'.rawurlencode($id).'?format=full'); }
function tango_gmail_list(string $query, ?string $pageToken=null): array {
    $path = 'messages?q='.rawurlencode($query).'&maxResults=50';
    if ($pageToken) $path .= '&pageToken='.rawurlencode($pageToken);
    return tango_gmail_api($path);
}
function tango_gmail_header_value(array $headers, string $name): string {
    foreach ($headers as $h) if (strcasecmp($h['name'] ?? '', $name) === 0) return (string)($h['value'] ?? '');
    return '';
}
function tango_gmail_decode_part(array $part): string {
    $data = $part['body']['data'] ?? '';
    if ($data !== '') return base64_decode(strtr($data, '-_', '+/')) ?: '';
    foreach (($part['parts'] ?? []) as $child) { $text = tango_gmail_decode_part($child); if ($text !== '') return $text; }
    return '';
}
function tango_gmail_plain_body(array $message): string {
    $text = tango_gmail_decode_part($message['payload'] ?? []);
    return trim(preg_replace('/\s+/', ' ', strip_tags($text)));
}
