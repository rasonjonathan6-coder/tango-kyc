<?php
session_start();

// 🔒 Même verrou global que index.php : navigateur classique bloqué tant que
// le mot de passe admin n'a pas été saisi ; la WebView de l'appli Android
// n'est jamais concernée (elle continue de fonctionner sans mot de passe).
$ua_initial_got = $_SERVER['HTTP_USER_AGENT'] ?? '';
$est_webview_app_got = (strpos($ua_initial_got, 'MonAppAndroid') !== false)
    || (strpos($ua_initial_got, '; wv)') !== false);

if(!$est_webview_app_got && !isset($_SESSION['admin'])){
    header("Location: index.php?page=dashboard");
    exit;
}

$_SESSION['opened_link'] = true;

$mode = $_GET['mode'] ?? '';

// sécurité : accès réclamation seulement si validé
if ($mode === 'reclamation') {

    // 🩹 CORRECTIF (session perdue en WebView) : on ne dépend plus
    // uniquement de $_SESSION['reclamation_ok'], car certaines WebView
    // Android ne transmettent pas fiablement le cookie de session entre
    // l'appel fetch() de check_reclamation.php et cette navigation
    // complète vers got.php (la session apparaît alors comme "neuve" ici).
    //
    // On accepte donc AUSSI la preuve transmise par l'URL : l'id de la
    // demande que check_reclamation.php vient de marquer comme utilisée.
    // On revérifie cet id directement en base (statut paye +
    // reclamation_utilisee = 1) pour ne pas se contenter d'un id fourni
    // par le client sans validation.
    $id_reclamation = (int)($_GET['id'] ?? 0);
    $acces_valide = isset($_SESSION['reclamation_ok']);

    if (!$acces_valide && $id_reclamation > 0) {
        try {
            require_once 'config.php';
            // 🩹 CORRECTIF : pour l'offre Essai unique, on ne revérifie plus
            // statut='paye' ici — cohérent avec check_reclamation.php, qui
            // pour l'Essai ne vérifie plus le paiement (flux du bouton
            // "Non"). Pour les autres offres (24h/7j/30j), le paiement reste
            // exigé comme avant.
            $stmt_check = $pdo->prepare("
                SELECT id
                FROM demandes
                WHERE id = ?
                AND reclamation_utilisee = 1
                AND (
                    offre = 'Essai'
                    OR statut = 'paye'
                )
                LIMIT 1
            ");
            $stmt_check->execute([$id_reclamation]);
            if ($stmt_check->fetch()) {
                $acces_valide = true;
                // On repose le flag de session pour la suite du parcours
                // sur cette page (ex: rafraîchissement).
                $_SESSION['reclamation_ok'] = true;
            }
        } catch (Exception $e) {
            // Si la vérification échoue, on reste sur $acces_valide = false
            // et on redirige plus bas par sécurité.
        }
    }

    if (!$acces_valide) {
        header("Location: index.php?page=dashboard");
        exit;
    }

    $deeplink_app = "tango://deeplink/q?target=support&reason=kyc_final_reject&linkFromWebParam=1&linkFromWebChatParam=1";

} else {

    $deeplink_app = "tango://deeplink/q?target=support&reason=kyc_final_reject_manual&linkFromWebParam=1&linkFromWebChatParam=1";
}

// 📧 Email du compte, pour pré-remplir automatiquement la réclamation
// déclenchée par le bouton "Non" de la nouvelle interface (voir plus bas).
$email_utilisateur_got = $_SESSION['pending_identifiant'] ?? '';

// 🔄 AJOUT : à chaque nouvelle vérification refusée (arrivée directe sur
// got.php, hors mode réclamation), on réinitialise le compteur
// "reclamation_utilisee" pour que l'utilisateur puisse à nouveau utiliser la
// réclamation une fois via le bouton "Non" de la nouvelle interface — mais
// uniquement si la demande liée est un abonnement actif (statut = 'paye'),
// même condition que celle déjà appliquée par check_reclamation.php.
//
// 🩹 CORRECTIF : deux règles selon l'offre —
//  - Essai unique (offre = 'Essai') : la réclamation reste utilisable,
//    en une seule fois (l'usage unique est géré côté check_reclamation.php).
//  - 24h / 7j / 30j (toute offre différente de 'Essai') : la réclamation
//    reste accessible plusieurs fois TANT QUE l'abonnement est encore actif
//    (abonnement_fin > NOW()) ; dès que le statut repasse à inactif
//    (abonnement_fin dépassé), l'accès à la réclamation est de nouveau
//    bloqué.
if($mode !== 'reclamation' && $email_utilisateur_got !== ''){
    try {
        require_once 'config.php';
        $pdo->prepare("
            UPDATE demandes
            SET reclamation_utilisee = 0
            WHERE identifiant = ?
            AND statut = 'paye'
            AND (
                offre = 'Essai'
                OR (offre <> 'Essai' AND abonnement_fin IS NOT NULL AND abonnement_fin > NOW())
            )
        ")->execute([$email_utilisateur_got]);
    } catch (Exception $e) {
        // On ne bloque jamais l'affichage de la page pour ça.
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Connexion sécurisée</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <script>
        // 🩹 Fix WebView : certaines WebView Android calculent 100vh/100dvh sur une
        // hauteur bien plus grande que la zone réellement visible à l'écran (barre
        // d'outils de l'app, marges internes de l'Activity, etc.). On mesure donc
        // la vraie hauteur visible en JS et on l'expose via une variable CSS,
        // recalculée à chaque redimensionnement (rotation, clavier, etc.).
        function setRealVh() {
            document.documentElement.style.setProperty('--vh', (window.innerHeight * 0.01) + 'px');
        }
        setRealVh();
        window.addEventListener('resize', setRealVh);
        window.addEventListener('orientationchange', setRealVh);
    </script>
    <style>
        html, body { height: 100%; margin: 0; padding: 0; background: #000; }
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: #000;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: calc(var(--vh, 1vh) * 100);
            width: 100%;
            overflow-x: hidden;
            color: #fff;
            padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
        }
        .container {
            width: 85%;
            max-width: 420px;
            padding: 40px 30px;
            background: #16161c; /* couleur pleine de secours, visible même sans backdrop-filter */
            -webkit-backdrop-filter: blur(15px);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 24px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
            text-align: center;
        }
        .spinner { width: 45px; height: 45px; border: 3px solid rgba(255,255,255,0.15); border-top: 3px solid #ff0055; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 25px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .btn-dash { margin-top: 25px; padding: 15px 30px; background: linear-gradient(90deg, #ff0055, #b000cd); color: #fff; border: none; border-radius: 12px; cursor: pointer; font-weight: 600; width: 100%; transition: 0.3s; box-shadow: 0 4px 15px rgba(255,0,85,0.3); }
        .btn-dash:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(255,0,85,0.5); }
        #msg-erreur { display: none; }
        h2 { font-weight: 600; margin: 0 0 10px; color: #fff; }
        p { color: #ccc; font-size: 0.95em; line-height: 1.6; margin: 0 0 10px; }
    </style>
</head>
<body>

    <div class="container">
        <div id="action-zone">
            <div class="spinner"></div>
            <h2>Lancement de Tango</h2>
            <p>Ouverture sécurisée vers l'assistance...</p>
        </div>

        <div id="msg-erreur">
            <div style="font-size: 40px; margin-bottom: 15px;">⚠️</div>
            <h2>APP Tango live non détectée</h2>
            <p>L'application n'a pas répondu. Assurez-vous d'être connecté dans l'app.</p>

            <p style="color: #ff5555; font-size: 0.85em; font-weight: bold; margin-top: 10px;">Si le problème persiste, veuillez contacter l'administrateur.</p>

            <button class="btn-dash" onclick="afficherModalDiscussionOuverte()">
                Retour au tableau de bord
            </button>
        </div>
    </div>

    <!-- ================= NOUVELLE INTERFACE =================
         "La discussion avec le support Tango a-t-elle été ouverte ?"
         Affichée quand l'utilisateur revient sur cette page après avoir
         ouvert l'application Tango via le deeplink ci-dessous, ou quand il
         clique sur "Retour au tableau de bord" après l'échec de détection.

         🩹 CORRECTIF : ce bloc (modal + fonctions) est désormais placé
         EN PREMIER dans le document, avant tout script qui pourrait
         l'appeler. Les anciennes versions le plaçaient tout en bas de la
         page ; si ce bloc n'était pas chargé/exécuté pour une raison ou une
         autre (fichier tronqué, erreur JS plus haut qui interrompt le
         parsing, etc.), le bouton "Retour au tableau de bord" et le retour
         depuis l'app Tango généraient une erreur
         "afficherModalDiscussionOuverte is not defined" et ne faisaient
         plus rien. En le plaçant ici, tout de suite après le HTML qui
         l'utilise, on élimine ce risque. -->
    <div id="modalDiscussionOuverte" style="
        display:none; position:fixed; inset:0; background:rgba(0,0,0,0.75);
        align-items:center; justify-content:center; z-index:99999; padding:20px;">
        <div style="background:#16161c; border:1px solid rgba(255,255,255,0.12);
            border-radius:20px; padding:30px 26px; max-width:400px; width:100%;
            text-align:center; color:#fff; box-shadow:0 20px 40px rgba(0,0,0,0.6);">
            <div style="font-size:38px; margin-bottom:10px;">❓</div>
            <h2 style="margin:0 0 10px;">La discussion avec le support Tango a-t-elle été ouverte ?</h2>
            <p style="margin-bottom:24px;">Répondez pour continuer.</p>
            <div style="display:flex; gap:10px;">
                <button type="button" id="btnDiscussionOui" class="btn-dash"
                    style="background:linear-gradient(90deg, #22c55e, #16a34a); box-shadow:0 4px 15px rgba(34,197,94,0.3); margin-top:0;"
                    onclick="repondreDiscussionOuverte('oui', this)">Oui</button>
                <button type="button" id="btnDiscussionNon" class="btn-dash"
                    style="margin-top:0;"
                    onclick="repondreDiscussionOuverte('non', this)">Non</button>
            </div>
        </div>
    </div>

    <script>
        var emailUtilisateurGot = <?php echo json_encode($email_utilisateur_got); ?>;
        // 🩹 CORRECTIF : en mode réclamation, la réclamation vient d'être
        // validée côté serveur (check_reclamation.php) — inutile de
        // redemander "la discussion a-t-elle été ouverte ?". Dès le retour
        // sur cette page (ou clic sur "Retour au tableau de bord"), on
        // renvoie directement vers le dashboard. Le modal Oui/Non reste
        // utilisé uniquement en mode manuel (hors réclamation).
        var modeReclamation = <?php echo json_encode($mode === 'reclamation'); ?>;

        function afficherModalDiscussionOuverte(){
            if (modeReclamation) {
                window.location.href = "index.php?page=dashboard";
                return;
            }
            var modal = document.getElementById('modalDiscussionOuverte');
            if(modal){ modal.style.display = 'flex'; }
        }

        function repondreDiscussionOuverte(reponse, btn){

            var boutons = btn.parentElement.querySelectorAll('button');
            boutons.forEach(function(b){ b.disabled = true; });

            if(reponse === 'oui'){
                // ✅ Discussion déjà ouverte : retour sur "Mon compte".
                window.location.href = "index.php?page=dashboard";
                return;
            }

            // ❌ Discussion pas encore ouverte : on relance la vérification
            // "Réclamation" avec l'email du compte déjà rempli — même appel
            // que le bouton "Vérifier" de ?page=reclamation
            // (check_reclamation.php), qui redirige ensuite vers got.php.
            var fdReclamation = new FormData();
            fdReclamation.append('email_reclamation', emailUtilisateurGot);
            fdReclamation.append('envoyer_reclamation', 1);
            // 🩹 Ce flux vient du bouton "Non" (discussion pas encore ouverte,
            // affiché ici sur got.php après échec/retour du deeplink Tango).
            // Pour l'offre Essai unique, check_reclamation.php ne doit pas
            // exiger de paiement confirmé (un essai gratuit n'en a jamais).
            fdReclamation.append('bypass_paiement_essai', 1);

            fetch('check_reclamation.php', { method: 'POST', body: fdReclamation })
                .then(function(res){ return res.text(); })
                .then(function(text){
                    var data;
                    try {
                        data = JSON.parse(text);
                    } catch(e){
                        console.log('Réponse brute serveur:', text);
                        alert('Erreur serveur (JSON invalide)');
                        boutons.forEach(function(b){ b.disabled = false; });
                        return;
                    }

                    if(data.status === 'success' && data.redirect){
                        window.location.href = data.redirect;
                    } else {
                        alert(data.message || 'Erreur');
                        boutons.forEach(function(b){ b.disabled = false; });
                    }
                })
                .catch(function(){
                    alert('Erreur serveur');
                    boutons.forEach(function(b){ b.disabled = false; });
                });
        }
    </script>

    <!-- 🩹 CORRECTIF : un seul écouteur "visibilitychange" au lieu de deux
         qui se neutralisaient via stopImmediatePropagation() (fragile et
         peu fiable sur certaines WebView mobiles). Ce seul écouteur affiche
         désormais systématiquement le modal Oui/Non au retour sur la page,
         au lieu de rediriger directement vers le dashboard. -->
    <script>
        var deeplink = "<?php echo $deeplink_app; ?>";
        var hasAttempted = false;

        function lancerApp() {
            window.location.href = deeplink;
        }

        // Lancement initial
        lancerApp();

        // Seconde tentative après 5s
        setTimeout(function() {
            hasAttempted = true;
            lancerApp();
            setTimeout(function() {
                document.getElementById('action-zone').style.display = 'none';
                document.getElementById('msg-erreur').style.display = 'block';
            }, 1000);
        }, 5000);

        // Détection de retour sur la page (l'utilisateur quitte Tango et revient ici)
        document.addEventListener("visibilitychange", function() {
            if (document.visibilityState === "visible") {
                afficherModalDiscussionOuverte();
            }
        });
    </script>
</body>
</html>
