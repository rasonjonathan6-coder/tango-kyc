<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Connexion sécurisée</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <script>
        // 🩹 Fix WebView : certaines WebView Android calculent 100vh/100dvh sur une
        // hauteur bien plus grande que la zone réellement visible à l'écran (barre
        // d'outils de l'app, marges internes de l'Activity, etc.). On mesure donc
        // la vraie hauteur visible en JS et on l'expose via une variable CSS,
        // recalculée à chaque redimensionnement (rotation, clavier, etc.).
        function setRealVh() {
            document.documentElement.style.setProperty('--vh', (window.innerHeight * 0.01) + 'px');
        }
        setRealVh();
        window.addEventListener('resize', setRealVh);
        window.addEventListener('orientationchange', setRealVh);
    </script>
    <style>
        html, body { height: 100%; margin: 0; padding: 0; background: #000; }
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: #000;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: calc(var(--vh, 1vh) * 100);
            width: 100%;
            overflow-x: hidden;
            color: #fff;
            padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
        }
        .container {
            width: 85%;
            max-width: 420px;
            padding: 40px 30px;
            background: #16161c; /* couleur pleine de secours, visible même sans backdrop-filter */
            -webkit-backdrop-filter: blur(15px);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 24px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
            text-align: center;
        }
        .spinner { width: 45px; height: 45px; border: 3px solid rgba(255,255,255,0.15); border-top: 3px solid #ff0055; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 25px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .btn-dash { margin-top: 25px; padding: 15px 30px; background: linear-gradient(90deg, #ff0055, #b000cd); color: #fff; border: none; border-radius: 12px; cursor: pointer; font-weight: 600; width: 100%; transition: 0.3s; box-shadow: 0 4px 15px rgba(255,0,85,0.3); }
        .btn-dash:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(255,0,85,0.5); }
        #msg-erreur { display: none; }
        h2 { font-weight: 600; margin: 0 0 10px; color: #fff; }
        p { color: #ccc; font-size: 0.95em; line-height: 1.6; margin: 0 0 10px; }
    </style>
</head>
<body>

    <div class="container">
        <div id="action-zone">
            <div class="spinner"></div>
            <h2>Lancement de Tango</h2>
            <p>Vérification de l'état de votre vérification en cours...</p>
        </div>

        <div id="msg-erreur">
            <div style="font-size: 40px; margin-bottom: 15px;">⚠️</div>
            <h2>APP Tango live non détectée</h2>
            <p>L'application n'a pas répondu. Assurez-vous d'être connecté dans l'app.</p>
            <p style="color: #ff5555; font-size: 0.85em; font-weight: bold; margin-top: 10px;">Si le problème persiste, veuillez contacter l'administrateur.</p>
            <button class="btn-dash" onclick="window.location.href='index.php?page=support'">
                Retour au choix
            </button>
        </div>
    </div>

    <script>
        var deeplink = "tango://deeplink/q?target=kyc_verification&linkFromWebParam=1&linkFromWebParam=1&linkFromWebChatParam=1";

        function lancerApp() {
            window.location.href = deeplink;
        }

        // Lancement initial
        lancerApp();

        // Seconde tentative après 5s
        setTimeout(function() {
            lancerApp();
            setTimeout(function() {
                document.getElementById('action-zone').style.display = 'none';
                document.getElementById('msg-erreur').style.display = 'block';
            }, 1000);
        }, 5000);

        // Détection de retour sur la page (l'utilisateur quitte Tango et revient ici)
        document.addEventListener("visibilitychange", function() {
            if (document.visibilityState === "visible") {
                window.location.href = "index.php?page=support";
            }
        });
    </script>
</body>
</html>
