<?php
// 🔒 Mêmes réglages de sécurité de session que index.php, pour partager la session utilisateur
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');

session_start();
header('Content-Type: application/json; charset=utf-8');
header("X-Robots-Tag: noindex, nofollow, noarchive", true);

require_once 'config.php';

if(!isset($_SESSION['user_id'])){
    echo json_encode([
        "success" => false,
        "message" => "Non connecté"
    ]);
    exit;
}

$stmt = $pdo->prepare("
    SELECT site, statut, montant, created_at
    FROM demandes
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 50
");
$stmt->execute([$_SESSION['user_id']]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Correspondance statut interne -> libellé affiché à l'utilisateur
$labels = [
    'paye'       => 'Payé',
    'en_attente' => 'En attente',
    'expire'     => 'Non payé',
];

$historique = [];
foreach($rows as $row){
    $historique[] = [
        "site"         => $row["site"],
        "statut_label" => $labels[$row["statut"]] ?? "Non payé",
        "montant"      => $row["montant"],
        "date"         => $row["created_at"] ? date("d/m/Y H:i", strtotime($row["created_at"])) : "",
    ];
}

echo json_encode([
    "success"    => true,
    "historique" => $historique
]);
