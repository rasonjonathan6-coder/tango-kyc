
session_start();
require_once "config.php";

$error = "";

if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Recherche de l'utilisateur dans la base de données
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // 1. Si l'e-mail n'existe pas du tout dans la base de données
    if (!$user) {
        $error = "❌ Aucun compte trouvé avec cet email. Veuillez d'abord vous inscrire.";
    } 
    // 2. Si le compte existe mais n'est pas vérifié
    elseif (!$user['verified']) {
        $error = "⚠️ Compte non vérifié. Vérifiez votre email.";
    } 
    // 3. Si le mot de passe est faux
    elseif (!password_verify($password, $user['password'])) {
        $error = "❌ Mot de passe incorrect.";
    } 
    // 4. Si tout est correct, on connecte et on redirige vers le paiement
    else {
        // Log de connexion
        $pdo->prepare("
            INSERT INTO login_logs (user_id, email, ip, user_agent)
            VALUES (?, ?, ?, ?)
        ")->execute([
            $user['id'],
            $user['email'],
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];

        header("Location: index.php?page=dashboard");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion Client</title>
    <style>
        body { font-family: Arial, sans-serif; background: radial-gradient(circle at 80% 20%, #ff057c 0%, #32004f 50%, #03001e 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; margin: 0; }
        .card { background: rgba(255,255,255,0.03); backdrop-filter: blur(25px); border: 1px solid rgba(255,255,255,0.12); border-radius: 30px; width: 100%; max-width: 400px; padding: 40px; text-align: center; color: white; box-shadow: 0 20px 50px rgba(0,0,0,0.5); }
        .input-group { margin-bottom: 20px; }
        .input-group input { width: 90%; padding: 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05); color: white; font-size: 16px; outline: none; }
        .btn-login { width: 100%; padding: 15px; border-radius: 12px; background: linear-gradient(135px, #ff057c, #8c00ff); border: none; color: white; font-size: 16px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn-login:hover { opacity: 0.9; transform: scale(1.02); }
        .link { display: block; margin-top: 20px; color: #00fff0; text-decoration: none; font-size: 14px; font-weight: bold; }
        .error-box { background: rgba(255, 85, 85, 0.2); border: 1px solid #ff5555; color: #ff8888; padding: 12px; border-radius: 10px; margin-bottom: 20px; font-weight: bold; font-size: 14px; }
    </style>
</head>
<body>

<div class="card">
    <h2 style="margin-bottom: 25px;">Connexion Espace Paiement</h2>
    
    <?php if(!empty($error)): ?>
        <div class="error-box"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="input-group">
            <input type="email" name="email" placeholder="Votre Email" required>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Votre Mot de passe" required>
        </div>
        <button type="submit" name="login" class="btn-login">SE CONNECTER</button>
    </form>
    
    <a href="register.php" class="link">Pas encore de compte ? S'inscrire ici</a>
</div>

</body>
</html>