<?php
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendMail($to, $subject, $message, $attachments = [], $inline_images = []){
    // Validation et nettoyage strict de l'adresse destinataire
    $to = trim((string)$to);
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        error_log("sendMail() : adresse destinataire invalide ou vide reçue : '" . $to . "'");
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'customerservicefor032@gmail.com';
        $mail->Password = 'qpjtyzjxhavqliso'; // Mot de passe d'application Google
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->Timeout = 10;
        $mail->SMTPKeepAlive = false;

        $mail->setFrom('customerservicefor032@gmail.com', 'Assistant Application Deblocage');
        $mail->addReplyTo('customerservicefor032@gmail.com', 'Assistant Application Deblocage');
        $mail->addAddress($to);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;

        // 📎 Pièces jointes optionnelles : $attachments accepte un chemin unique
        // (string) ou un tableau de chemins. Un chemin manquant/illisible est
        // simplement ignoré (log d'avertissement) pour ne jamais bloquer l'envoi.
        if(!empty($attachments)){
            if(!is_array($attachments)){
                $attachments = [$attachments];
            }
            foreach($attachments as $chemin_piece_jointe){
                if($chemin_piece_jointe && is_readable($chemin_piece_jointe)){
                    $mail->addAttachment($chemin_piece_jointe);
                } else {
                    error_log("sendMail() : pièce jointe introuvable ou illisible : '" . $chemin_piece_jointe . "'");
                }
            }
        }

        // 🖼️ Images intégrées (inline) optionnelles : $inline_images est un
        // tableau associatif ['cid' => 'chemin/vers/image']. L'image est
        // embarquée dans le mail et référencée dans le corps via src="cid:XXX".
        // Un chemin manquant/illisible est simplement ignoré (log d'avertissement)
        // pour ne jamais bloquer l'envoi.
        if(!empty($inline_images)){
            foreach($inline_images as $cid_image => $chemin_image_inline){
                if($chemin_image_inline && is_readable($chemin_image_inline)){
                    $mail->addEmbeddedImage($chemin_image_inline, $cid_image);
                } else {
                    error_log("sendMail() : image inline introuvable ou illisible : '" . $chemin_image_inline . "'");
                }
            }
        }

        // Extraction ou conversion du contenu
        $estDejaHtml = (strpos($message, '<') !== false && strpos($message, '>') !== false);

        if ($estDejaHtml) {
            // Si le message contient des balises <body>...</body>, on récupère le contenu interne
            if (preg_match('/<body[^>]*>(.*?)<\/body>/is', $message, $matches)) {
                $contenu = $matches[1];
            } else {
                $contenu = $message;
            }
        } else {
            $contenu = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));
        }

        $mail->isHTML(true);

        // Template HTML unique et propre
        $mail->Body = '
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
</head>
<body style="margin:0;padding:0;background:#f4f6fb;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6fb;padding:30px 15px;">
<tr>
<td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 10px rgba(0,0,0,0.05);">
<tr>
<td align="center" style="padding:20px;">
<img src="https://deblocagetango.com/jh-logo2.png" width="120" alt="Jhacy" style="display:block;margin:auto;">
</td>
</tr>
<tr>
<td style="padding:20px;color:#333;font-size:16px;line-height:1.2;">
'.$contenu.'
</td>
</tr>
<tr>
<td align="center" style="padding:20px;background:#f8f8f8;color:#666;font-size:13px;">
© '.date('Y').' Administrateur-Exchange-Support Tango — Tous droits réservés.
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>';

        $mail->AltBody = strip_tags($message);

        $envoye = $mail->send();
        if(!$envoye){
            error_log("PHPMailer échec vers $to : " . $mail->ErrorInfo);
        }
        return $envoye;

    } catch (Exception $e) {
        error_log("PHPMailer error vers $to : " . $mail->ErrorInfo . " / exception : " . $e->getMessage());
        return false;
    } catch (Throwable $e) {
        error_log("Erreur inattendue dans sendMail() vers $to : " . $e->getMessage());
        return false;
    }
}