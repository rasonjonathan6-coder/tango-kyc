<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

require_once "config.php";
require_once "mail.php";
require_once "send_push.php";
$paymentId = $_POST["payment_id"] ?? "";

$phone = trim($_POST["phone"] ?? "");

if($paymentId == "" || $phone == ""){

    echo json_encode([
        "success"=>false,
        "message"=>"Informations manquantes."
    ]);

    exit;
}

/* Vérification du numéro MVola
   Accepte les numéros commençant par 034 ou 038 */
if(!preg_match('/^0(34|38)[0-9]{7}$/', $phone)){

    echo json_encode([
        "success"=>false,
        "message"=>"Numéro MVola invalide."
    ]);

    exit;
}

/* Vérifie que le paiement existe */
$stmt = $pdo->prepare("

SELECT id, identifiant, statut, manual_payment, offre, montant
FROM demandes
WHERE payment_id=?
LIMIT 1
");

$stmt->execute([$paymentId]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$user){

    echo json_encode([
        "success"=>false,
        "message"=>"Paiement introuvable."
    ]);

    exit;
}

/* Paiement déjà confirmé */
if($user["statut"] == "paye"){

    echo json_encode([
        "success"=>false,
        "message"=>"Ce paiement est déjà traité."
    ]);

    exit;
}

/* Demande déjà envoyée */
if($user["manual_payment"] == 1){

    echo json_encode([
        "success"=>false,
        "message"=>"Votre demande a déjà été envoyée."
    ]);

    exit;
}

/* Enregistrement */
$stmt = $pdo->prepare("
UPDATE demandes
SET
    statut='en_attente',
    manual_payment=1,
    manual_status=1,
    notification_active=1,
    sender_phone=?
WHERE payment_id=?
");
$stmt->execute([
    $phone,
    $paymentId
]);

if($stmt->rowCount()==0){

    echo json_encode([
        "success"=>false,
        "message"=>"Impossible d'enregistrer la demande."
    ]);

    exit;
}

/* 🏷️ Offre choisie + montant, enregistrés lors de la création de la demande
   (colonnes "offre" et "montant" de la table demandes). Repli si absents
   (anciennes demandes créées avant l'ajout de la colonne "offre"). */
$offreChoisie = !empty($user["offre"]) ? $user["offre"] : "Offre standard";
$montantAffiche = number_format((float) $user["montant"], 0, ',', ' ') . " Ar";

sendPush(
    "💰 Paiement MVola reçu",
    "📧 Client : ".$user["identifiant"]."\n📱 MVola : ".$phone."\n🏷️ Offre : ".$offreChoisie."\n💵 Montant : ".$montantAffiche,
    [
        "id" => $user["id"],
        "identifiant" => $user["identifiant"],
        "sender_phone" => $phone,
        "offre" => $offreChoisie,
        "montant" => $user["montant"]
    ]
);

/* Email admin */
$mail = "customerservicefor032@gmail.com";

$subject = "Nouvelle demande de paiement manuel";

$message =
"Nouvelle demande de paiement MVola\n\n".
"Email : ".$user["identifiant"]."\n".
"Numéro MVola : ".$phone."\n".
"Offre choisie : ".$offreChoisie."\n".
"Montant : ".$montantAffiche."\n".
"Paiement : ".$paymentId;

sendMail(
    $mail,
    $subject,
    nl2br($message)
);

echo json_encode([
    "success"=>true,
    "message"=>"Votre demande a bien été envoyée."
]);