<?php
session_start();
require_once "config.php";
require_once "taux.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// ===============================
// CONFIG ORANGE MONEY
// ===============================
$numeroOrange = "0325610639"; // Votre numéro Orange Money
$duree = 600; // 10 minutes

// Récupération des données envoyées par index.php
$montant = isset($_POST['montant']) ? floatval($_POST['montant']) : 0;
$offre = $_POST['offre'] ?? "";

$email = "";
$stmt = $pdo->prepare("SELECT email FROM users WHERE id=?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if($user){
    $email = $user['email'];
}

// Code USSD Orange Money
$numeroOrange = "0325610639";

$codeUSSD = "#144*1*1*{$numeroOrange}*{$numeroOrange}*{$montant}*2#";
?>
<!DOCTYPE html>
<html lang="fr">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Paiement Orange Money</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Inter',sans-serif;
}

body{

background:#0f0f10;
color:#fff;
overflow-x:hidden;

}

body::before{

content:"";
position:fixed;
inset:0;

background:
radial-gradient(circle at 80% 20%,rgba(255,115,0,.35),transparent 30%),
radial-gradient(circle at 20% 80%,rgba(255,145,0,.25),transparent 35%),
linear-gradient(180deg,#111,#181818);

z-index:-1;

}

.container{

max-width:500px;
margin:auto;
padding:22px;

}

.card{

background:rgba(255,255,255,.06);

border:1px solid rgba(255,255,255,.12);

backdrop-filter:blur(20px);

border-radius:28px;

padding:24px;

margin-bottom:24px;

box-shadow:0 20px 40px rgba(0,0,0,.35);

}

.header{

display:flex;
justify-content:space-between;
align-items:center;

margin-bottom:20px;

}

.logo{

width:70px;
height:70px;
background:#000;
border-radius:18px;

display:flex;
justify-content:center;
align-items:center;

}

.logo img{

width:50px;

}

.lang{

background:#111;
border-radius:40px;
padding:5px;
display:flex;
gap:5px;

}

.lang span{

padding:10px 18px;
border-radius:30px;

font-weight:700;

}

.lang .active{

background:#fff;
color:#ff6a00;

}

.title{

font-size:38px;
font-weight:800;

margin-top:15px;

}

.orange{

color:#ff7900;

}

.subtitle{

opacity:.85;
margin-top:10px;
font-size:18px;
line-height:30px;

}

.amount{

text-align:center;

}

.amount small{

font-size:20px;
opacity:.8;

}

.amount h1{

font-size:56px;
margin-top:12px;
color:#ff7900;

}

.label{

font-weight:700;
margin-bottom:12px;
font-size:20px;

}

.input{

background:rgba(255,255,255,.05);

border:1px solid rgba(255,255,255,.08);

border-radius:18px;

height:68px;

display:flex;
align-items:center;

padding:0 20px;

font-size:18px;

margin-bottom:22px;

}

.input img{

width:26px;
margin-right:15px;

}

.code{

display:flex;
gap:10px;

}

.code input{

flex:1;

height:70px;

border:none;
outline:none;

background:#101010;
color:#fff;

padding:0 20px;

border-radius:18px;

font-size:20px;
font-weight:700;

}

.copy{

width:145px;

border:none;

background:linear-gradient(90deg,#ff7900,#ff5400);

color:#fff;

font-size:19px;

font-weight:700;

border-radius:18px;

cursor:pointer;

}

.pay{

margin-top:25px;

height:68px;

border:none;

width:100%;

border-radius:20px;

font-size:24px;

font-weight:800;

color:#fff;

background:linear-gradient(90deg,#ff7900,#ff5b00);

box-shadow:0 12px 30px rgba(255,121,0,.35);

cursor:pointer;

}

.timer{

margin-top:22px;

text-align:center;

font-size:19px;

color:#ffb15a;

font-weight:700;

}

.info{

margin-top:18px;
text-align:center;
opacity:.9;

}

@media(max-width:600px){

.title{
font-size:30px;
}

.amount h1{
font-size:42px;
}

}

</style>

</head>

<body>

<div class="container">

<div class="card">

<div class="header">

<div class="logo">

<img src="images/orangemoney.png">

</div>

<div class="lang">

<span class="active">FR</span>

<span>EN</span>

</div>

</div>

<div class="title">

Paiement manuel <span class="orange">Orange Money</span>

</div>

<div class="subtitle">

Suivez les étapes ci-dessous pour effectuer votre paiement.

</div>

</div>
                           <!-- ===========================
CARTE MONTANT
============================ -->

<div class="card amount">

    <small>Montant à payer</small>

    <h1><?= number_format($montant,0,","," ") ?> MGA</h1>

</div>

<!-- ===========================
FORMULAIRE
============================ -->

<form action="confirmation_orange.php" method="POST">

<input type="hidden" name="offre" value="<?= htmlspecialchars($offre) ?>">

<input type="hidden" name="montant" value="<?= $montant ?>">

<div class="card">

<div class="label">
Votre email
</div>

<div class="input">

<img src="images/email.png">

<?= htmlspecialchars($email) ?>

</div>

<div class="label">
Composez ce code Orange Money
</div>

<div class="code">

<input
type="text"
id="ussd"
readonly
value="<?= htmlspecialchars($codeUSSD) ?>">

<button
type="button"
class="copy"
onclick="copierCode()">

Copier

</button>

</div>

<div style="height:15px;"></div>

<a
href="tel:<?= $ussdDial ?>"
style="
display:block;
text-align:center;
padding:18px;
background:linear-gradient(90deg,#ff7900,#ff5b00);
border-radius:18px;
color:#fff;
font-size:20px;
font-weight:700;
text-decoration:none;
">

📞 Composer automatiquement le code

</a>

<div style="height:25px"></div>

<div class="label">

Numéro Orange Money ayant envoyé l'argent

</div>

<div class="input">

<img src="images/phone.png">

<input

type="text"

name="numero"

placeholder="032xxxxxxx"

required

style="background:none;
border:none;
outline:none;
width:100%;
font-size:18px;
color:#fff;">

</div>

<div class="timer">

Temps restant :

<span id="timer">

10:00

</span>

</div>

<button

class="pay"

type="submit">

✓ J'ai payé

</button>

<div class="info">

Le paiement sera confirmé en quelques secondes.

</div>

</div>

</form>

</div>

<script>

function copierCode(){

let code=document.getElementById("ussd");

code.select();

code.setSelectionRange(0,99999);

navigator.clipboard.writeText(code.value);

let btn=document.querySelector(".copy");

btn.innerHTML="Copié ✓";

setTimeout(function(){

btn.innerHTML="Copier";

},2000);

}

// =========================
// MINUTEUR
// =========================

let temps=<?= $duree ?>;

function countdown(){

let min=Math.floor(temps/60);

let sec=temps%60;

if(sec<10){

sec="0"+sec;

}

document.getElementById("timer").innerHTML=min+":"+sec;

if(temps<=0){

alert("Le délai de paiement est expiré.");

window.location="index.php";

}

temps--;

}

countdown();

setInterval(countdown,1000);

</script>

</body>

</html>