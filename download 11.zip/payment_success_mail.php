<?php

function sendPaymentSuccessMail($pdo, $paymentId)
{
    require_once "mail.php";

    $stmt = $pdo->prepare("
        SELECT identifiant
        FROM demandes
        WHERE payment_id=?
        LIMIT 1
    ");

    $stmt->execute([$paymentId]);

    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if($client){

        sendMail(
            $client["identifiant"],
            "Paiement confirmé ",
            "
Bonjour,

Votre paiement a été confirmé avec succès.

Votre demande est maintenant prise en charge.

Vous pouvez contacter notre support via la discussion disponible dans votre espace client.

Si la discussion avec le support ne veut pas s'ouvrir, veuillez aller dans la rubrique Réclamation et envoyer votre demande avec votre adresse email afin que notre équipe puisse vous répondre.

Merci pour votre confiance.

Assistant DEBLOCAGE TANGO

"
        );

    }
}