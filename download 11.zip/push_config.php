<?php

define(
    "VAPID_PUBLIC_KEY",
    "BPhAz2IGWKDpwM3kh0WeHJND9a3aMqT-mSbo0iag0bONJrijXYD2tNqisPo3Azrdv4HTvJVe0oh8eoiLVnB-euc"
);

define(
    "VAPID_PRIVATE_KEY",
    "Y-cKqYGE8-_3lih1NMxy875RzWSdKF-ZGdpH_0ohdJ0"
);