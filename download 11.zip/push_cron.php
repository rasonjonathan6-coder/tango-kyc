<?php

require_once "config.php";
require_once "send_push.php";


$stmt = $pdo->prepare("
    SELECT identifiant, sender_phone
    FROM demandes
    WHERE notification_active = 1
");

$stmt->execute();

$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);


foreach($payments as $index => $p){


    if($index > 0){

        sleep(30);

    }


    sendPush(
        "💵 Paiement MVola en attente",
        "📧 Client : ".$p["identifiant"].
        "\n📱 MVola : ".$p["sender_phone"]
    );


}


echo "OK";