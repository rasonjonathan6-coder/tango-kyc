<?php

session_start();

require_once "config.php";

if(!isset($_SESSION["user_id"])){

    exit;

}

$userId=$_SESSION["user_id"];

$messageId=intval($_POST["id"]??0);

$stmt=$pdo->prepare("
INSERT IGNORE INTO messages_admin_lus
(message_id,user_id)
VALUES(?,?)
");

$stmt->execute([

$messageId,

$userId

]);

echo "OK";