<?php

// 1. Libérer les wallets dont le paiement est expiré
$pdo->prepare("
UPDATE wallets w
JOIN demandes d
ON w.reserved_payment_id = d.payment_id
SET
    w.status='free',
    w.reserved_payment_id=NULL,
    w.reserved_at=NULL,
    w.last_used_at=NOW(),
    d.statut='non_paye'
WHERE
    d.statut='en_attente'
    AND d.expiration_time <= NOW()
")->execute();


// 2. Libérer les wallets orphelins
$pdo->prepare("
UPDATE wallets
SET
    status='free',
    reserved_payment_id=NULL,
    reserved_at=NULL,
    last_used_at=NOW()
WHERE
    status='reserved'
    AND reserved_payment_id IS NOT NULL
    AND reserved_payment_id NOT IN (
        SELECT payment_id
        FROM demandes
    )
")->execute();
function releaseWallet(PDO $pdo, $paymentId){

    $stmt = $pdo->prepare("
        UPDATE wallets
        SET
            status='free',
            reserved_payment_id=NULL,
            reserved_at=NULL,
            last_used_at=NOW()
        WHERE reserved_payment_id=?
    ");

    $stmt->execute([$paymentId]);

}