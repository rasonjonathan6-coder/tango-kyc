<?php

session_start();

if(!isset($_SESSION["admin"])){
    exit("Accès refusé");
}

require_once "config.php";
require_once "mail.php";
require_once "send_push.php";

$id = intval($_GET["id"] ?? 0);

$stmt = $pdo->prepare("
SELECT *
FROM messages_admin
WHERE id=?
LIMIT 1
");

$stmt->execute([$id]);

$msg = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$msg){
    exit("Campagne introuvable.");
}

$cible = $msg["cible"];

if($cible=="tous"){

    $users = $pdo->query("
    SELECT email
    FROM users
    ")->fetchAll(PDO::FETCH_ASSOC);

}elseif($cible=="paye"){

    $users = $pdo->query("
    SELECT DISTINCT identifiant AS email
    FROM demandes
    WHERE statut='paye'
    ")->fetchAll(PDO::FETCH_ASSOC);

}elseif($cible=="attente"){

    $users = $pdo->query("
    SELECT DISTINCT identifiant AS email
    FROM demandes
    WHERE statut='en_attente'
    ")->fetchAll(PDO::FETCH_ASSOC);

}else{

    $users = $pdo->query("
    SELECT DISTINCT identifiant AS email
    FROM demandes
    WHERE statut='expired'
    ")->fetchAll(PDO::FETCH_ASSOC);

}
if($msg["envoyer_email"]){

    foreach($users as $u){

        sendMail(

            $u["email"],

            $msg["sujet"],

            nl2br($msg["message"])

        );

    }

}

if($msg["envoyer_push"]){

    sendPush(

        $msg["sujet"],

        $msg["message"]

    );

}

header("Location: admin_campaigns.php?success=1");

exit;