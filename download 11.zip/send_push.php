<?php

require_once __DIR__ . "/vendor/autoload.php";
require_once __DIR__ . "/push_config.php";

use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

// Fichier de log lisible directement (utile si les logs serveur ne sont pas accessibles).
// À SUPPRIMER une fois le diagnostic terminé.
function debugPushLog($ligne){
    $fichier = __DIR__ . "/debug_push.log";
    $horodatage = date("Y-m-d H:i:s");
    file_put_contents($fichier, "[$horodatage] $ligne\n", FILE_APPEND);
}

function sendPush($title, $body, $data = [], $userIdCible = null){

    global $pdo;

    debugPushLog("=== Appel sendPush : titre=\"$title\"".($userIdCible !== null ? " (ciblé user_id=$userIdCible)" : "")." ===");

    if($userIdCible !== null){
        $stmt = $pdo->prepare("SELECT * FROM push_subscriptions WHERE user_id = ?");
        $stmt->execute([$userIdCible]);
    } else {
        $stmt = $pdo->query("
        SELECT * FROM push_subscriptions
        ");
    }

    $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    debugPushLog("Abonnements trouvés en base : ".count($subscriptions));

    if(empty($subscriptions)){
        debugPushLog("Aucun abonnement -> rien à envoyer.");
        return 0;
    }

    if(!defined('VAPID_PUBLIC_KEY') || !defined('VAPID_PRIVATE_KEY') || VAPID_PUBLIC_KEY === '' || VAPID_PRIVATE_KEY === ''){
        debugPushLog("ERREUR : clés VAPID absentes ou vides dans push_config.php");
        return 0;
    }

    try{
        $webPush = new WebPush([
            'VAPID' => [
                'subject'    => 'mailto:customerservicefor032@gmail.com',
                'publicKey'  => VAPID_PUBLIC_KEY,
                'privateKey' => VAPID_PRIVATE_KEY
            ]
        ]);
    } catch(Throwable $e){
        debugPushLog("ERREUR construction WebPush (clés VAPID invalides ?) : ".$e->getMessage());
        return 0;
    }

    $nbFilesEnvoyees = 0;

    foreach($subscriptions as $sub){

        // Filtre de sécurité : un endpoint invalide (ex: valeur "test" laissée
        // en base) ferait planter Subscription::create() ou le flush() plus bas
        // et bloquerait l'envoi pour TOUS les autres abonnés. On l'ignore et on
        // le signale dans le log au lieu de casser toute la boucle.
        if(empty($sub['endpoint']) || !filter_var($sub['endpoint'], FILTER_VALIDATE_URL) || strpos($sub['endpoint'], 'http') !== 0){
            debugPushLog("IGNORÉ (endpoint invalide, id=".($sub['id'] ?? '?').") : ".substr($sub['endpoint'] ?? '', 0, 60));
            continue;
        }

        debugPushLog("File d'attente pour endpoint : ".substr($sub['endpoint'], 0, 60)."...");

        try{
            $subscription = Subscription::create([
                'endpoint'  => $sub['endpoint'],
                'publicKey' => $sub['public_key'],
                'authToken' => $sub['auth_token']
            ]);

            $webPush->queueNotification(
                $subscription,
                json_encode([
                    "title"=>$title,
                    "body"=>$body,
                    "data"=>$data
                ])
            );

            $nbFilesEnvoyees++;

        } catch(Throwable $e){
            debugPushLog("ERREUR mise en file (id=".($sub['id'] ?? '?').") : ".$e->getMessage());
        }
    }

    $success = 0;

    if($nbFilesEnvoyees === 0){
        debugPushLog("Aucun abonnement valide à envoyer après filtrage.");
        return 0;
    }

    // Le flush() envoie réellement les requêtes HTTP vers les services push.
    // Sans ce try/catch, une exception ici (endpoint injoignable, erreur réseau,
    // etc.) arrêtait tout le script AVANT d'écrire les logs OK/ÉCHEC/Résultat final
    // — exactement ce qui était observé dans debug_push.log.
    try{
        $reports = $webPush->flush();
    } catch(Throwable $e){
        debugPushLog("ERREUR pendant flush() : ".$e->getMessage());
        error_log("Erreur Push (flush) : ".$e->getMessage());
        return $success;
    }

    foreach($reports as $report){

        $endpointCourt = substr($report->getEndpoint(), 0, 60)."...";

        if($report->isSuccess()){
            $success++;
            debugPushLog("OK envoyé à : ".$endpointCourt);
        }else{
            debugPushLog("ÉCHEC pour ".$endpointCourt." — raison : ".$report->getReason()." (expiré : ".($report->isSubscriptionExpired() ? "oui" : "non").")");
            error_log(
                "Erreur Push : ".$report->getReason()
            );

            // Un abonnement expiré ne redeviendra jamais valide : on le
            // supprime de la base pour ne plus polluer les prochains envois.
            if($report->isSubscriptionExpired()){
                try{
                    $stmtDel = $pdo->prepare("DELETE FROM push_subscriptions WHERE endpoint = ?");
                    $stmtDel->execute([$report->getEndpoint()]);
                    debugPushLog("Abonnement expiré supprimé de la base : ".$endpointCourt);
                } catch(Throwable $e){
                    debugPushLog("ERREUR suppression abonnement expiré : ".$e->getMessage());
                }
            }
        }
    }

    debugPushLog("Résultat final : $success envoi(s) réussi(s) sur ".count($subscriptions));

    return $success;
}