<?php
/**
 * ⏰ Rappel "abonnement bientôt expiré" — à exécuter périodiquement via une
 * tâche cron (ex : toutes les 15-30 minutes), PAS à ouvrir dans un navigateur.
 *
 * Exemple de tâche cron (toutes les 15 minutes) :
 *   *\/15 * * * * php /chemin/vers/send_rappel_expiration.php >> /chemin/vers/rappel_abonnement.log 2>&1
 *
 * Cherche les demandes payées dont l'abonnement se termine dans moins de
 * 24h (colonne "abonnement_fin", posée à la confirmation du paiement) et
 * envoie un email de rappel à l'utilisateur concerné — une seule fois par
 * abonnement, grâce à la colonne "rappel_expiration_envoye".
 *
 * Ne concerne que les offres avec une durée fixe (Pack 24h / 7 Jours /
 * 30 Jours) : "Essai" est limité en nombre d'ouvertures, pas dans le temps,
 * et n'a donc jamais de "abonnement_fin" renseigné.
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . "/config.php";
require_once __DIR__ . "/mail.php";

// Sécurité : si ce script est accidentellement ouvert depuis un navigateur,
// on continue quand même à fonctionner (il ne fait qu'envoyer des emails),
// mais on précise que l'usage prévu est une tâche cron.
$estCli = (php_sapi_name() === 'cli');

$stmt = $pdo->prepare("
    SELECT id, identifiant, offre, abonnement_fin
    FROM demandes
    WHERE statut = 'paye'
    AND abonnement_fin IS NOT NULL
    AND abonnement_fin > NOW()
    AND abonnement_fin <= (NOW() + INTERVAL 24 HOUR)
    AND (rappel_expiration_envoye IS NULL OR rappel_expiration_envoye = 0)
");
$stmt->execute();
$aRappeler = $stmt->fetchAll(PDO::FETCH_ASSOC);

$nbEnvoyes = 0;

foreach ($aRappeler as $demande) {

    if (empty($demande['identifiant'])) {
        continue;
    }

    $finFormatee = date('d/m/Y à H:i', strtotime($demande['abonnement_fin']));
    $offre = $demande['offre'] ?: 'votre abonnement';

    $sujet = "⏰ Votre abonnement se termine bientôt";

    $message =
        "Bonjour,<br><br>" .
        "Votre abonnement <strong>" . htmlspecialchars($offre) . "</strong> se termine le " .
        "<strong>" . $finFormatee . "</strong> (dans moins de 24h).<br><br>" .
        "Pensez à renouveler votre abonnement si vous souhaitez continuer à ouvrir " .
        "des discussions avec le support Tango sans interruption.<br><br>" .
        "Merci de votre confiance.";

    $envoiOk = sendMail($demande['identifiant'], $sujet, $message);

    // On marque comme envoyé même si sendMail() échoue silencieusement côté
    // fournisseur, pour éviter un envoi en boucle toutes les 15 minutes ;
    // en cas de vrai échec technique, retirer temporairement cette ligne
    // permet de forcer un nouvel essai au prochain passage du cron.
    $pdo->prepare("UPDATE demandes SET rappel_expiration_envoye = 1 WHERE id = ?")
        ->execute([$demande['id']]);

    $nbEnvoyes++;
}

$resultat = "Rappels envoyés : $nbEnvoyes / " . count($aRappeler) . " demande(s) trouvée(s).";

if ($estCli) {
    echo $resultat . PHP_EOL;
} else {
    header("Content-Type: text/plain; charset=utf-8");
    echo $resultat;
}
