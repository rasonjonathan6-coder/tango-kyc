
self.addEventListener("push", event => {

    let data = {};

    if(event.data){
        data = event.data.json();
    }

    event.waitUntil(
        (async () => {

            await self.registration.showNotification(

                data.title || "? Nouveau paiement manuel",

                {
                    body:
                    data.body ||
                    "Un client vient de cliquer sur J'ai payé",

                    icon:"/icon-192.png",

                    badge:"/icon-192.png",

                    vibrate:[
                        1000,
                        500,
                        1000,
                        500,
                        1000
                    ],

                    requireInteraction:true,

                    tag:"paiement-manuel",

                    renotify:true,

                    // On stocke les infos du client (id / email / téléphone)
                    // pour pouvoir les réutiliser au clic sur la notification.
                    data: data.data || {}

                }

            );

            // Si l'espace admin est déjà ouvert (même en arrière-plan),
            // on le prévient immédiatement pour lancer l'écran d'appel + la voix
            // sans attendre que l'admin clique sur la notification.
            const allClients = await clients.matchAll({
                type: "window",
                includeUncontrolled: true
            });

            for(const client of allClients){
                client.postMessage({
                    type: "manual_payment_call",
                    payload: data.data || {}
                });
            }

        })()
    );

});

// Au clic sur la notification : rouvre (ou remet au premier plan) l'espace admin
// et lui transmet les infos du paiement pour déclencher l'écran d'appel + la voix.
self.addEventListener("notificationclick", event => {

    const payload = event.notification.data || {};

    event.notification.close();

    event.waitUntil(
        (async () => {

            const windowClients = await clients.matchAll({
                type: "window",
                includeUncontrolled: true
            });

            for(const client of windowClients){
                if(client.url.includes("page=admin") && "focus" in client){
                    await client.focus();
                    client.postMessage({
                        type: "manual_payment_call",
                        payload
                    });
                    return;
                }
            }

            if(clients.openWindow){

                const newClient = await clients.openWindow("/?page=admin");

                // On laisse le temps à la page de charger avant de lui
                // envoyer les infos du paiement.
                if(newClient){
                    setTimeout(()=>{
                        newClient.postMessage({
                            type: "manual_payment_call",
                            payload
                        });
                    }, 2500);
                }

            }

        })()
    );

});