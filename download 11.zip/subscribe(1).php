<?php

header("Content-Type: application/json");

require_once "config.php";

// Table des abonnements push (un admin peut avoir plusieurs appareils/navigateurs)
$pdo->query("
CREATE TABLE IF NOT EXISTS push_subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    endpoint_hash CHAR(64) UNIQUE,
    endpoint TEXT,
    public_key TEXT,
    auth_token TEXT,
    created_at DATETIME,
    updated_at DATETIME
)
");

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if(
    !$data ||
    empty($data["endpoint"]) ||
    empty($data["keys"]["p256dh"]) ||
    empty($data["keys"]["auth"])
){
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Abonnement invalide."
    ]);
    exit;
}

$endpoint   = $data["endpoint"];
$public_key = $data["keys"]["p256dh"];
$auth_token = $data["keys"]["auth"];
$hash       = hash("sha256", $endpoint);
$now        = date("Y-m-d H:i:s");

$stmt = $pdo->prepare("
INSERT INTO push_subscriptions (endpoint_hash, endpoint, public_key, auth_token, created_at, updated_at)
VALUES (?, ?, ?, ?, ?, ?)
ON DUPLICATE KEY UPDATE
    public_key = VALUES(public_key),
    auth_token = VALUES(auth_token),
    updated_at = VALUES(updated_at)
");

$stmt->execute([
    $hash,
    $endpoint,
    $public_key,
    $auth_token,
    $now,
    $now
]);

echo json_encode([
    "success" => true
]);