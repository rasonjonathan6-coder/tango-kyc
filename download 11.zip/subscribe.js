const VAPID_PUBLIC_KEY = "BPhAz2IGWKDpwM3kh0WeHJND9a3aMqT-mSbo0iag0bONJrijXYD2tNqisPo3Azrdv4HTvJVe0oh8eoiLVnB-euc";


async function enableNotifications(){

    const permission = await Notification.requestPermission();

    if(permission !== "granted"){
        alert("Notification refusée");
        return;
    }


    const registration = await navigator.serviceWorker.register(
        "/service-worker.js"
    );


    const subscription = await registration.pushManager.subscribe({

        userVisibleOnly:true,

        applicationServerKey:urlBase64ToUint8Array(
            VAPID_PUBLIC_KEY
        )

    });


    // IMPORTANT : sur iOS/Safari, JSON.stringify(subscription) ne remplit pas
    // toujours correctement le champ "keys". On extrait donc manuellement
    // endpoint + p256dh + auth pour garantir une sérialisation fiable
    // sur tous les navigateurs (Chrome, Firefox, Safari/iOS).
    const rawP256dh = subscription.getKey("p256dh");
    const rawAuth   = subscription.getKey("auth");

    const payload = {
        endpoint: subscription.endpoint,
        keys: {
            p256dh: arrayBufferToBase64Url(rawP256dh),
            auth: arrayBufferToBase64Url(rawAuth)
        }
    };

    const response = await fetch("/subscribe.php", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify(payload)

    });

    const result = await response.json();

    if(!result.success){
        alert("❌ Échec de l'enregistrement : " + (result.message || "erreur inconnue"));
        return;
    }

    alert("✅ Notifications activées");

}



function urlBase64ToUint8Array(base64String){

    const padding = "=".repeat(
        (4 - base64String.length % 4) % 4
    );


    const base64 = (
        base64String + padding
    )
    .replace(/\-/g, "+")
    .replace(/_/g, "/");


    const rawData = window.atob(base64);


    return Uint8Array.from(
        [...rawData].map(
            char => char.charCodeAt(0)
        )
    );

}


// Convertit un ArrayBuffer (retourné par subscription.getKey()) en base64url,
// le format texte attendu par le serveur / la lib minishlink/web-push.
function arrayBufferToBase64Url(buffer){

    const bytes = new Uint8Array(buffer);

    let binary = "";

    for(const byte of bytes){
        binary += String.fromCharCode(byte);
    }

    const base64 = window.btoa(binary);

    return base64
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "");

}