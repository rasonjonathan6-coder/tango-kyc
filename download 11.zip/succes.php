<?php
session_start();
require_once "config.php";

// Plisio ajoute ces paramètres à l'URL de succès une fois le paiement terminé
$order_number = $_GET['order_number'] ?? ($_GET['txn_id'] ?? '');

$demande = null;

if ($order_number !== '') {
    $stmt = $pdo->prepare("SELECT * FROM demandes WHERE payment_id = ? LIMIT 1");
    $stmt->execute([$order_number]);
    $demande = $stmt->fetch(PDO::FETCH_ASSOC);
}

// ⚠️ IMPORTANT :
// On ne marque JAMAIS la demande comme "payée" ici. Cette page n'est que
// l'endroit où revient le navigateur — un visiteur pourrait y arriver sans
// avoir payé. Le vrai statut vient de la Status URL (callback signé par
// Plisio) qui doit déjà avoir mis à jour "statut" en base avant que
// l'utilisateur n'atterrisse ici.
$deja_confirme = $demande && $demande['statut'] === 'paye';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Paiement réussi</title>
<style>
*{box-sizing:border-box;}
body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    font-family:Inter,system-ui,Arial,sans-serif;
    background:linear-gradient(135deg,#111827,#1e3a8a,#047857);
    padding:20px;
}
.card{
    background:rgba(17,24,39,.85);
    border:1px solid rgba(255,255,255,.1);
    border-radius:28px;
    padding:40px 30px;
    max-width:420px;
    width:100%;
    text-align:center;
    box-shadow:0 25px 60px rgba(0,0,0,.4);
}
.icon{
    width:78px;
    height:78px;
    margin:0 auto 20px;
    border-radius:50%;
    background:linear-gradient(135deg,#10b981,#047857);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:38px;
    color:white;
}
h1{color:#fff;font-size:22px;margin:0 0 10px;}
p{color:rgba(255,255,255,.7);font-size:14px;line-height:1.6;margin:0 0 25px;}
.status{
    display:inline-block;
    padding:6px 14px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    margin-bottom:20px;
}
.status.ok{background:rgba(16,185,129,.15);color:#38e8a5;}
.status.pending{background:rgba(245,158,11,.15);color:#f59e0b;}
.btn{
    display:inline-block;
    background:linear-gradient(135deg,#10b981,#047857);
    color:white;
    text-decoration:none;
    font-weight:600;
    padding:14px 28px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(16,185,129,.3);
}
</style>
</head>
<body>

<div class="card">
    <div class="icon">✓</div>
    <h1>Paiement effectué</h1>

    <?php if ($deja_confirme): ?>
        <span class="status ok">🟢 Confirmé</span>
        <p>Votre paiement a bien été confirmé. Votre accès est maintenant actif.</p>
    <?php else: ?>
        <span class="status pending">🟡 Confirmation en cours</span>
        <p>Nous avons bien reçu votre paiement. Sa confirmation peut prendre quelques instants — vous serez notifié dès qu'elle sera validée.</p>
    <?php endif; ?>

    <a href="index.php?page=compte" class="btn">Retour à mon compte</a>
</div>

</body>
</html>
