<?php
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['success'=>false,'error'=>'Connexion requise']); exit; }
$reference=trim((string)($_GET['reference']??''));
if($reference===''){echo json_encode(['success'=>false,'error'=>'Référence manquante']);exit;}
$st=$pdo->prepare('SELECT id,reference_code,profile_link,status,created_at,last_reply_at FROM tango_support_requests WHERE user_id=? AND reference_code=? LIMIT 1');$st->execute([(int)$_SESSION['user_id'],$reference]);$request=$st->fetch(PDO::FETCH_ASSOC);
if(!$request){http_response_code(404);echo json_encode(['success'=>false,'error'=>'Demande introuvable']);exit;}
$msg=$pdo->prepare('SELECT sender_email,subject,message,received_at,status FROM tango_support_messages WHERE request_id=? ORDER BY received_at ASC,id ASC');$msg->execute([(int)$request['id']]);
echo json_encode(['success'=>true,'request'=>$request,'messages'=>$msg->fetchAll(PDO::FETCH_ASSOC)],JSON_UNESCAPED_UNICODE);
