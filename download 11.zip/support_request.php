<?php
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gmail_service.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function support_json(array $data, int $status=200): never { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
if (empty($_SESSION['user_id'])) support_json(['success'=>false,'error'=>'Connexion requise'],401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') support_json(['success'=>false,'error'=>'Méthode invalide'],405);
$csrf = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (empty($_SESSION['csrf_tango_support']) || !hash_equals($_SESSION['csrf_tango_support'], $csrf)) support_json(['success'=>false,'error'=>'Session expirée'],419);
$profile = trim((string)($_POST['profile_link'] ?? ''));
$identity = trim((string)($_POST['tango_identity'] ?? ''));
if ($profile === '' || $identity === '') support_json(['success'=>false,'error'=>'Veuillez remplir les deux champs.'],422);
if (mb_strlen($profile) > 500 || mb_strlen($identity) > 255) support_json(['success'=>false,'error'=>'Valeur trop longue.'],422);
$profileIsUrl = filter_var($profile, FILTER_VALIDATE_URL) !== false;
$profileIsId = preg_match('/^[A-Za-z0-9._-]{3,100}$/', $profile) === 1;
if (!$profileIsUrl && !$profileIsId) support_json(['success'=>false,'error'=>'Lien ou identifiant de profil Tango invalide.'],422);
$isEmail = filter_var($identity, FILTER_VALIDATE_EMAIL) !== false;
$isPhone = preg_match('/^\+?[0-9][0-9 .()\-]{6,24}$/', $identity) === 1;
if (!$isEmail && !$isPhone) support_json(['success'=>false,'error'=>'Saisissez un e-mail ou un numéro valide.'],422);
$profile = preg_replace('/[\r\n\t]+/', ' ', $profile);
$siteStmt=$pdo->prepare('SELECT email FROM users WHERE id=? LIMIT 1'); $siteStmt->execute([(int)$_SESSION['user_id']]); $siteEmail=(string)$siteStmt->fetchColumn();
if (!filter_var($siteEmail,FILTER_VALIDATE_EMAIL)) support_json(['success'=>false,'error'=>'E-mail du compte introuvable.'],422);
try { $pdo->exec("ALTER TABLE users ADD COLUMN tango_profile_link VARCHAR(500) NULL"); } catch (Throwable $e) {}
$saveProfile = $pdo->prepare('UPDATE users SET tango_profile_link=? WHERE id=?');
try { $saveProfile->execute([$profile,(int)$_SESSION['user_id']]); } catch (Throwable $e) { error_log('Tango profile save failed: '.$e->getMessage()); }
$pdo->exec("CREATE TABLE IF NOT EXISTS tango_support_requests (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,site_email VARCHAR(255) NOT NULL,profile_link VARCHAR(500) NOT NULL,tango_email VARCHAR(255) NULL,tango_phone VARCHAR(40) NULL,reference_code VARCHAR(64) NOT NULL,status VARCHAR(30) NOT NULL DEFAULT 'pending',gmail_thread_id VARCHAR(128) NULL,gmail_message_id VARCHAR(256) NULL,last_reply_at DATETIME NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uq_ref(reference_code),KEY idx_user(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$reference='TANGO-KYC-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
$tangoEmail=$isEmail?$identity:null; $tangoPhone=$isPhone?$identity:null;
$duplicate=$pdo->prepare("SELECT reference_code FROM tango_support_requests WHERE user_id=? AND profile_link=? AND status IN ('pending','sent','waiting_reply') AND created_at > (NOW() - INTERVAL 24 HOUR) ORDER BY id DESC LIMIT 1");
$duplicate->execute([(int)$_SESSION['user_id'],$profile]);
if($existing=$duplicate->fetchColumn()) support_json(['success'=>true,'reference'=>$existing,'already_exists'=>true]);
$insert=$pdo->prepare('INSERT INTO tango_support_requests (user_id,site_email,profile_link,tango_email,tango_phone,reference_code,status) VALUES (?,?,?,?,?,?,?)');
$insert->execute([(int)$_SESSION['user_id'],$siteEmail,$profile,$tangoEmail,$tangoPhone,$reference,'pending']); $requestId=(int)$pdo->lastInsertId();
$c=tango_gmail_config(); $subject='Manual KYC Verification Request - Profil Link '.$profile;
$identityLine=$isEmail?'Registered Email: '.$tangoEmail:'Registered Number: '.$tangoPhone;
$body="Hello Compliance Team,\n\nI am requesting a manual review of my identity verification (KYC).\nI have valid official government documents ready for submission to prove my identity.\n\nMy Account Information:\n- Profile Link: {$profile}\n- {$identityLine}\n\nPlease reset or manually review my verification status.\nIf possible, please send me a new verification link so I can complete the verification process again.\n\nThank you.\n\nReference:\n{$reference}\n";
try { $sent=tango_gmail_send($c['support_email'],$subject,$body); $up=$pdo->prepare('UPDATE tango_support_requests SET status="waiting_reply",gmail_message_id=? WHERE id=?'); $up->execute([$sent['id']??null,$requestId]); support_json(['success'=>true,'reference'=>$reference]); }
catch(Throwable $e){ error_log('Tango Gmail request failed: '.$e->getMessage()); support_json(['success'=>false,'error'=>'La demande n’a pas pu être envoyée. Réessayez plus tard.'],502); }
