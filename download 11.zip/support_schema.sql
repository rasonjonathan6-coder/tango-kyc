-- Système de demandes KYC Tango via Gmail OAuth 2.0
-- Version compatible avec les bases existantes.
-- Exécuter ce fichier une seule fois dans la base de l'application.

CREATE TABLE IF NOT EXISTS tango_support_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    site_email VARCHAR(255) NOT NULL,
    profile_link VARCHAR(500) NOT NULL,
    tango_email VARCHAR(255) NULL,
    tango_phone VARCHAR(40) NULL,
    reference_code VARCHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    gmail_thread_id VARCHAR(128) NULL,
    gmail_message_id VARCHAR(256) NULL,
    last_reply_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tango_support_reference (reference_code),
    KEY idx_tango_support_user (user_id),
    KEY idx_tango_support_thread (gmail_thread_id),
    KEY idx_tango_support_message (gmail_message_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tango_support_messages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    request_id BIGINT UNSIGNED NULL,
    user_id INT NULL,
    reference_code VARCHAR(64) NULL,
    gmail_message_id VARCHAR(256) NOT NULL,
    gmail_thread_id VARCHAR(128) NULL,
    sender_email VARCHAR(255) NULL,
    subject VARCHAR(500) NULL,
    message LONGTEXT NOT NULL,
    received_at DATETIME NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'received',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tango_support_gmail_message (gmail_message_id),
    KEY idx_tango_support_message_request (request_id),
    KEY idx_tango_support_message_reference (reference_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tango_support_oauth_state (
    id TINYINT UNSIGNED NOT NULL,
    state_hash CHAR(64) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tango_support_sync_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    last_history_id VARCHAR(128) NULL,
    synced_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Aucun FOREIGN KEY volontairement : les types de users.id varient selon les installations.
-- La sécurité est assurée dans le code par user_id = $_SESSION['user_id'].
-- Les index user_id et request_id restent présents pour les performances.

-- Variables serveur attendues :
-- TANGO_SUPPORT_EMAIL
-- TANGO_GMAIL_CLIENT_ID
-- TANGO_GMAIL_CLIENT_SECRET
-- TANGO_GMAIL_REDIRECT_URI
-- TANGO_GMAIL_REFRESH_TOKEN
-- TANGO_GMAIL_USER
