<?php
require 'mail.php';

$email = "rasonjonathan6t@gmail.com";

if(sendMail($email, "Test SMTP", "<h2>Email OK 🚀</h2>")){
    echo "✅ Email envoyé avec succès";
} else {
    echo "❌ Échec envoi email";
}