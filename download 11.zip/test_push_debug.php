<?php

// ⚠️ Fichier de DIAGNOSTIC UNIQUEMENT.
// À supprimer une fois le problème résolu (il expose des infos techniques).

header("Content-Type: text/plain; charset=utf-8");

require_once "config.php";
require_once __DIR__ . "/vendor/autoload.php";
require_once "push_config.php";

use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

echo "=== 1. Vérification des abonnements enregistrés ===\n\n";

$stmt = $pdo->query("SELECT id, endpoint, created_at, updated_at FROM push_subscriptions ORDER BY updated_at DESC");
$subs = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(empty($subs)){
    echo "❌ AUCUN abonnement trouvé dans push_subscriptions.\n";
    echo "   => Le clic sur 'Activer les notifications' n'a pas réussi à enregistrer\n";
    echo "      l'abonnement côté serveur (vérifier subscribe.php / la console JS du navigateur).\n";
    exit;
}

echo "✅ " . count($subs) . " abonnement(s) trouvé(s) :\n\n";

foreach($subs as $s){
    $isApple = strpos($s["endpoint"], "web.push.apple.com") !== false;
    echo "- ID {$s['id']} | " . ($isApple ? "📱 iPhone (Apple)" : "🌐 Autre navigateur") . "\n";
    echo "  Endpoint : " . substr($s["endpoint"], 0, 60) . "...\n";
    echo "  Créé le : {$s['created_at']} | Mis à jour le : {$s['updated_at']}\n\n";
}

echo "\n=== 2. Test d'envoi réel d'une notification ===\n\n";

$webPush = new WebPush([
    'VAPID' => [
        'subject'    => 'mailto:customerservice032@gmail.com',
        'publicKey'  => VAPID_PUBLIC_KEY,
        'privateKey' => VAPID_PRIVATE_KEY
    ]
]);

foreach($subs as $sub){

    $stmt2 = $pdo->prepare("SELECT * FROM push_subscriptions WHERE id = ?");
    $stmt2->execute([$sub["id"]]);
    $full = $stmt2->fetch(PDO::FETCH_ASSOC);

    $subscription = Subscription::create([
        'endpoint'  => $full['endpoint'],
        'publicKey' => $full['public_key'],
        'authToken' => $full['auth_token']
    ]);

    $webPush->queueNotification(
        $subscription,
        json_encode([
            "title" => "🔔 Test diagnostic",
            "body"  => "Si vous voyez ceci, le push fonctionne !",
            "data"  => ["id" => 0, "identifiant" => "TEST", "sender_phone" => "0000000000"]
        ])
    );
}

foreach($webPush->flush() as $report){

    $endpoint = $report->getRequest()->getUri()->__toString();

    if($report->isSuccess()){
        echo "✅ SUCCÈS pour : " . substr($endpoint, 0, 60) . "...\n";
    }else{
        echo "❌ ÉCHEC pour : " . substr($endpoint, 0, 60) . "...\n";
        echo "   Raison : " . $report->getReason() . "\n";
        echo "   Code HTTP : " . ($report->getResponse() ? $report->getResponse()->getStatusCode() : "N/A") . "\n\n";
    }
}
