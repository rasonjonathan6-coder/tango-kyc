<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
</head>
<body>

<h2>📩 Test UTF-8</h2>

<p>é è à ç ù</p>

</body>
</html>