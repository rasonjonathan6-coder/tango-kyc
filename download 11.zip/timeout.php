<?php

$pdo = new PDO(
    "mysql:host=sql303.infinityfree.com;dbname=if0_42287821_TANGO;charset=utf8",
    "if0_42287821",
    "Jirama501"
);

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pid = $_GET['pid'] ?? '';

if ($pid != '') {

    $stmt = $pdo->prepare("
        SELECT expiration_time, statut
        FROM demandes
        WHERE payment_id=?
        LIMIT 1
    ");
    $stmt->execute([$pid]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {

        if (
            strtotime($row['expiration_time']) < time()
            && $row['statut'] == 'en_attente'
        ) {

            $pdo->beginTransaction();

            // Libérer le wallet USDT
            $pdo->prepare("
                UPDATE wallets
                SET
                    status='free',
                    reserved_payment_id=NULL,
                    reserved_at=NULL,
                    last_used_at=NOW()
                WHERE reserved_payment_id=?
            ")->execute([$pid]);

            // Supprimer complètement la demande
            $pdo->prepare("
                DELETE FROM demandes
                WHERE payment_id=?
                AND statut='en_attente'
            ")->execute([$pid]);

            $pdo->commit();
        }
    }
}

echo "ok";