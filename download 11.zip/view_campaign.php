<?php

session_start();

if(!isset($_SESSION["admin"])){
    exit("Accès refusé");
}

require_once "config.php";

$id = intval($_GET["id"] ?? 0);

$stmt = $pdo->prepare("
SELECT *
FROM messages_admin
WHERE id=?
LIMIT 1
");

$stmt->execute([$id]);

$msg = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$msg){
    exit("Message introuvable.");
}

?>

<!DOCTYPE html>

<html lang="fr">

<head>

<meta charset="UTF-8">

<title>Détails de la campagne</title>

<link rel="stylesheet" href="admin_style.css?v=<?= @filemtime(__DIR__.'/admin_style.css') ?: time() ?>">

</head>

<body class="admin-page">

<?php $admin_nav_active = 'campagnes'; include "admin_nav.php"; ?>

<div class="admin-card" style="max-width:900px;margin:0 auto;">

<h2 class="admin-title">📢 Détails de la campagne</h2>

<p><b style="color:var(--admin-text-muted);">Sujet :</b> <?= htmlspecialchars($msg["sujet"]) ?></p>

<p><b style="color:var(--admin-text-muted);">Cible :</b> <?= htmlspecialchars($msg["cible"]) ?></p>

<p><b style="color:var(--admin-text-muted);">Date :</b> <?= htmlspecialchars($msg["created_at"]) ?></p>

<p><b style="color:var(--admin-text-muted);">Email :</b> <?= $msg["envoyer_email"] ? "✅ Oui" : "❌ Non" ?></p>

<p><b style="color:var(--admin-text-muted);">Push :</b> <?= $msg["envoyer_push"] ? "✅ Oui" : "❌ Non" ?></p>

<p><b style="color:var(--admin-text-muted);">Dashboard :</b> <?= $msg["afficher_dashboard"] ? "✅ Oui" : "❌ Non" ?></p>

<h3 class="admin-card-title" style="margin-top:20px;">Message</h3>

<div style="background:var(--admin-bg-elevated);border:1px solid var(--admin-border);padding:18px;border-radius:var(--admin-radius-md);white-space:pre-wrap;">

<?= htmlspecialchars($msg["message"]) ?>

</div>

</div>

</body>

</html>