<?php

define(
    "PLISIO_SECRET_KEY",
    "5ETUGnDrfaFOY2HPrR5m0NJxqKk4XN74SbSCeUe3h4bryKqaREI9TPz5uK-0nRzj"
);

define(
    "PLISIO_API_URL",
    "https://api.plisio.net/api/v1"
);

?>